README for VGA driver with GEM/5 colour palette
-----------------------------------------------

This archive contains the source and binary of a 640x480x16 VGA
driver for GEM, but modified to use the GEM/5 colour palette (with
additional shades of grey and some new colours).

To install the driver straight away, copy SDGEM5.VGA to your GEMSYS
directory, and rename any screen drivers already present:

C:\>CD GEMAPPS\GEMSYS
C:\GEMAPPS\GEMSYS>REN SD*.* SC*.*
C:\GEMAPPS\GEMSYS>COPY <unzipdir>\SDGEM5.VGA
   1 file(s) copied.

It's only very slightly modified from Chris Barnes' driver source,
and builds in the same way (I tidied up the build batch file and
renamed it to BUILD.BAT though).  The only changes are in IBM.A86,
where I stripped out the ifs for everything but 4-plane video and
added a palette table (16 rows of 3 bytes, describing RGB for the
first 16 colour indices in the VGA's RAMDAC).  I also changed the
initial_color_table to switch the VGA to using the first 16 indices
rather than the standard 16 dotted throughout the table.

This method has its drawbacks.  I'm pretty sure all the colours
used in this driver already exist in the table - the first 8 are
there for certain, and I reckon the second group are just at
different indices than the normal dark colours.  For those with
an interest in the hardware side of things, the VGA controller
when in 640x480x16 mode has 4 palettes of 64 colours, of which 1
palette can be active and 16 of the colours in that palette can be
assigned to the colour values 0-15.  (Technically, the adapter can
be told to use 16 palettes of 16 colours, or can be dropped into
320x240x256 colour, which uses all 4 palettes.)  These are set via
the standard INT 10h video interrupt, function 10h, subfunctions
2h, 12h and 13h:

Int 10h         Function 10h                                    VIDEO
                Set Palette Registers

Controls operations on the color palette registers in PCjr, EGA, VGA
and MCGA video controllers.

Calling
  registers: AH      10h
             AL      02h, set all registers and border (not on MCGA)
               ES:DX Pointer to 17-byte colour list
             AL      12h, set block of colour registers (MCGA and
                          VGA only)
               BX    First color register to set
               CX    Number of color registers to set
               ES:DX Pointer to color values
             AL      13h, select color page (VGA only)
               BL    00h, select paging mode
               BH    Paging mode
                     00h 4 register blocks of 64 registers
                     01h 16 register blocks of 16 registers
             AL      13h, select color page (VGA only)
               BL    01h, select page
               BH    Page number
                     00-03h for 64 register blocks
                     00-0Fh for 16 register blocks

(taken from DOS Programmer's Reference, 3e.)

The existing DRI code used subfunction 2 to change the indices used for
the default colours, while my code uses that subfunction to switch to
the indices 00-0Fh and then changes those indices to reflect the GEM/5
colour palette, as taken from John Elliott's web site.  This is done
during the switch to graphics mode, so the palette gets reset upon
return from DOS programs, alleviating the effects seen with GEM/5's
DOS shell.  I think the VGA hardware is also reset when switching
back to text mode, so the changes are undone then.  They may, however,
be left in place - I'll have to add code to save and restore the VGA
configuration at appropriate places.  Also, the two tables used to
match colours to colour representations (the driver can return the
red, green and blue values for each colour it can draw) have not been
updated for the GEM/5 scheme.

Thanks to John for his list of the GEM/5 colour palette, and also for
pointing out that the VGA registers are only 6 bits wide, which was
the reason the colours in the last release were so dark.

Regards,
Ben A L Jemmett
(18th April, 2000).
