------------------------------------------------------------------------
FreeGEM/XM                                              Release 3.0beta4
Source distribution                                       Build 20000406
README.TXT - FreeGEM/XM Desktop
------------------------------------------------------------------------
Copyright (C) Digital Research, Inc. 1985 - 1986.
          (C) Caldera Thin Clients, Inc. 1999.
          (C) FreeGEM Programmers, 2000.
          This software is released under the GNU General Public License
------------------------------------------------------------------------

This directory contains source to the GEM/XM 3.0beta4 / 3.0B3 Desktop.

I changed the Info... box to reflect the new copyright information and
version.  Work on adapting the standard FreeGEM Desktop to work with
FreeGEM/XM is progressing.

Regards,
Ben A L Jemmett
6th April, 2000.
