

#include "ppdgem.h"
#include "ppdg0.h"



	WORD
appl_exit()
{
	gem_if(APPL_EXIT);
	return( TRUE );
}
