

#include "ppdgem.h"
#include "ppdg0.h"



	WORD
rsrc_free()
{
	return( gem_if( RSRC_FREE ) );
}
