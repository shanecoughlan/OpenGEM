

#include "ppdgem.h"
#include "ppdg0.h"



	VOID
appl_yield()
{
	gem_if(APPL_YIELD);
}
