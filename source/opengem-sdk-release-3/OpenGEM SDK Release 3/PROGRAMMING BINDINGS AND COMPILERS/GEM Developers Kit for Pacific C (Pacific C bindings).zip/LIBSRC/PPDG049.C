

#include "ppdgem.h"
#include "ppdg0.h"



	WORD
scrp_clear()
{
	return( gem_if( SCRP_CLEAR ) );
}
