/* DESKCLRS.C - Desktop colour scheme code              */

/* (C)opyright Ben A L Jemmett 2000.  This software is  */
/* released under the GNU Public License.  See the file */
/* LICENSE.TXT (included) for more information.         */

/* Changes:                                             */
/* 19990522 - BALJ - Moved code from DESKTOP.C to here. */
/* 20000205 - BALJ - Removed all system colour code.    */
/*                   Added SETTINGS.APP code here.      */
/*                   Added icon colouring code.         */

#include <portab.h>
#include <machine.h>
#include <obdefs.h>
#include <taddr.h>
#include <dos.h>
#include <gembind.h>
#include <desktop.h>
#include <deskapp.h>
#include <deskfpd.h>
#include <deskwin.h>
#include <infodef.h>
#include <deskbind.h>
#include <deskclrs.h>

EXTERN VOID	show_hide();
EXTERN WORD	form_do();
EXTERN WORD     movs();
EXTERN WORD	pro_run();
EXTERN WORD	objc_draw();
EXTERN WORD     objc_offset();
EXTERN WORD     on_newgem;

#if MULTIAPP
EXTERN WORD	pr_kbytes;
#endif

EXTERN GLOBES	G;

        VOID
change_tree(LONG tree, WORD parent)
{
        /* Recursively walk the tree, to let us change any objects
           around as needed -- BALJ, 20000422.                  */

        WORD    i;

        for(i=LWGET(OB_HEAD(parent)); i<=LWGET(OB_TAIL(parent)); i++)
        {

          /* do this object */
          switch (LHIBT(LWGET(OB_TYPE(i)))) /* switch on ext. obj. type */
          {
            case 254:           /* Underbar - set colouring             */
              if (clrs_dlgdec & 0xf0)
                LWSET(OB_FLAGS(i), LWGET(OB_FLAGS(i)) | HIDETREE);
              else
              {
                LWSET(OB_FLAGS(i), LWGET(OB_FLAGS(i)) & ~HIDETREE);
                LWSET(LLGET(OB_SPEC(i))+18,
                  (LWGET(LLGET(OB_SPEC(i))+18) & 0xf0ff) |
                    ((clrs_dlgdec & 0x0f) * 0x100 ));
              }
              break;
            case 253:            /* Check/radio obj - change for FreeGEM */
              if (on_newgem)
                LWSET(OB_TYPE(i), G_STRING);
              break;
          }

          /* do object's children recursively */
          if (LWGET(OB_HEAD(i)) != -1)
            change_tree(tree, i);
        }
}

        VOID
change_bars(VOID)
{
        /* Routine to look at all objects and change title underbars
           (extended type 254/-2) to the right colour */

        LONG    tree;
        WORD    i;

        for (i=0; i<NUM_ADTREES; i++)
          change_tree(G.a_trees[i], ROOT);

}



        WORD
clrs_find(pstart, ib_char)
        FNODE *pstart;
        WORD  ib_char;                        
{
        WORD    index;
        WORD    curr_fore, curr_back;

        if (G.g_useorigcol) return(ib_char);

        index = curr_fore = curr_back = 0;

        switch (pstart->f_pa->a_type)
        {
          case AT_ISFOLD:
            index = (pstart->f_attr & F_FAKE) ? CI_FAKE : CI_FOLD;
            break;
          case AT_ISDISK:
            index = CI_DISK;
            break;
          case AT_ISSHRT:
            index = CI_SHRT;
            break;
          case AT_ISTRSH:
            index = CI_TRSH;
            break;
          case AT_ISFILE:
            index = (pstart->f_isap) ? CI_GAPP:
                                       CI_GDOC;
            if (is_installed(pstart->f_pa)) index++;
            break;
        }

        curr_fore = (col_info[index] & 0xff00) / 0x100;
        curr_back = col_info[index] & 0x00ff;

        if ((curr_fore == 0) && (curr_back == 0)) curr_fore = 1;

        ib_char = (curr_fore * 0x1000);
        ib_char |= (curr_back * 0x0100);
        
        return(ib_char);
}

        WORD
ask_colour( tree, obj)
        LONG tree;
        WORD obj;
{
        WORD    i, touchob, retval;
        WORD    xd, yd, wd, hd, done, current;
        LONG    obspec;

                /* Routine to pop up the colour palette in the dialog   */
                /* Assumes:  * Dialog has already been drawn on screen  */
                /*           * Palette is unmodified from my original   */
                /*           * obj is a valid object in tree            */
                /* Sets the colour of the object specified.             */

        current = (WORD) LLGET(OB_SPEC(obj)) & 0xf;

        LWSET(OB_X(COLOURPL), LWGET(OB_X(obj)));
        LWSET(OB_Y(COLOURPL), LWGET(OB_Y(obj)));
        LWSET(OB_FLAGS(COLOURPL), LWGET(OB_FLAGS(COLOURPL)) & ~HIDETREE);

        LWSET(OB_FLAGS(CLROK), LWGET(OB_FLAGS(CLROK)) & ~SELECTABLE);
        LWSET(OB_FLAGS(CLRCAN), LWGET(OB_FLAGS(CLRCAN)) & ~SELECTABLE);

        for (i=CLR0; i<=CLRF; i++)
          LLSET(OB_SPEC(i), LLGET(OB_SPEC(i)) & 0x0000FFFF);

        LLSET(OB_SPEC(CLR0+current), ( LLGET(OB_SPEC(CLR0+current)) & 0x0000FFFF) | 0x00010000);

        objc_offset(tree, COLOURPL, &xd, &yd);
        hd = LWGET(OB_HEIGHT(COLOURPL));
        wd = LWGET(OB_WIDTH(COLOURPL));

        xd -= 3; yd -= 3; hd += 6; wd += 6;

        objc_draw(tree, ROOT, MAX_DEPTH, xd, yd, wd, hd);

        retval = current;

        done = FALSE;
        while (!done)
        {
                touchob = form_do(tree, 0);

                if ( (touchob >= CLR0) && (touchob <= CLRF) )
                {
                  retval = touchob - CLR0;
                  done = TRUE;
                }
        }

        LWSET(OB_FLAGS(CLROK), LWGET(OB_FLAGS(CLROK)) | SELECTABLE);
        LWSET(OB_FLAGS(CLRCAN), LWGET(OB_FLAGS(CLRCAN)) | SELECTABLE);

        LWSET(OB_FLAGS(COLOURPL), LWGET(OB_FLAGS(COLOURPL)) | HIDETREE);

        obspec = LLGET(OB_SPEC(obj));
        obspec &= ~0xF;
        obspec |= (retval & 0xF);
        LLSET(OB_SPEC(obj), obspec);

        objc_draw(tree, ROOT, MAX_DEPTH, xd, yd, wd, hd);

        return(retval);
}

        WORD
draw_cntrls(tree, local)
        LONG tree;
        ICONBLK *local;
{
        WORD    tx, ty, tw, th;
        WORD    iwx, iwy, iwh, iww;
        LONG    obspec;

        objc_offset(tree, ICNWIN, &iwx, &iwy);
        iwh = LWGET(OB_HEIGHT(ICNWIN));
        iww = LWGET(OB_WIDTH(ICNWIN));

        objc_offset(tree, WINSHADE, &tx, &ty);
        tw = LWGET(OB_WIDTH(WINSHADE));
        th = LWGET(OB_HEIGHT(WINSHADE));
        objc_draw(tree, WINSHADE, MAX_DEPTH, tx, ty, tw, th);

        objc_offset(tree, ICNBG, &tx, &ty);
        tw = LWGET(OB_WIDTH(ICNBG));
        th = LWGET(OB_HEIGHT(ICNBG));
        objc_draw(tree, ICNBG, MAX_DEPTH, tx, ty, tw, th);

        objc_offset(tree, ICNFG, &tx, &ty);
        tw = LWGET(OB_WIDTH(ICNFG));
        th = LWGET(OB_HEIGHT(ICNFG));
        objc_draw(tree, ICNFG, MAX_DEPTH, tx, ty, tw, th);

        objc_offset(tree, WINCOL1, &tx, &ty);
        tw = LWGET(OB_WIDTH(WINCOL1));
        th = LWGET(OB_HEIGHT(WINCOL1));
        objc_draw(tree, WINCOL1, MAX_DEPTH, tx, ty, tw, th);

        objc_offset(tree, DLGDEC, &tx, &ty);
        tw = LWGET(OB_WIDTH(DLGDEC));
        th = LWGET(OB_HEIGHT(DLGDEC));
        objc_draw(tree, DLGDEC, MAX_DEPTH, tx, ty, tw, th);

        obspec = LLGET(OB_SPEC(ICNWIN));
        obspec &= ~0x7f;
        obspec |= LLGET(OB_SPEC(WINCOL1)) & 0xf;
        obspec |= LLGET(OB_SPEC(WINSHADE)) & 0x70;
        LLSET(OB_SPEC(ICNWIN), obspec);

        objc_draw(tree, ICNWIN, MAX_DEPTH, iwx, iwy, iww, iwh);
        local->ib_char &= 0x00ff;
        local->ib_char |= (LLGET(OB_SPEC(ICNBG)) & 0xf) * 0x0100;
        local->ib_char |= (LLGET(OB_SPEC(ICNFG)) & 0xf) * 0x1000;
        objc_draw(tree, ICNWIN, MAX_DEPTH, iwx, iwy, iww, iwh);
        return(0);
}

        WORD
do_colours()
{
        LONG    tree, obspec;
        LONG    address;
        WORD    touchob, done, icon, shade, i;
        WORD    iwx, iwy, iwh, iww;

        BYTE    curr_fore, curr_back;
        WORD    my_col_info[11];

        ICONBLK local;

        WORD    iconnums[9]={0, 2, 2, 2, 3, 8, 10, 40, 42};
        BYTE    iconstrs[9][12];

        for (i=0; i<9; i++)
          strcpy( ini_str(STIDESC1+i), &iconstrs[i][0] );

        for (i=0; i<8; i++)
          my_col_info[i] = col_info[i];
        my_col_info[9] = clrs_wind;
        my_col_info[10] = clrs_dlgdec;
        if (clrs_dlgdec & 0xf0)
          LWSET(OB_FLAGS(HIDEDEC), LWGET(OB_FLAGS(HIDEDEC)) & SELECTED);

        tree = G.a_trees[ADCLRS];

        LWSET(OB_FLAGS(COLOURPL), LWGET(OB_FLAGS(COLOURPL)) | HIDETREE);

        icon=0;

        LLSET(OB_SPEC(ICNWIN), (LLGET(OB_SPEC(ICNWIN)) & ~0xFF ) | clrs_wind);

        obspec = LLGET(OB_SPEC(WINCOL1));
        obspec &= ~0xf;
        obspec |= clrs_wind & 0x0f;
        LLSET(OB_SPEC(WINCOL1), obspec);

        obspec = LLGET(OB_SPEC(DLGDEC));
        obspec &= ~0xf;
        obspec |= clrs_dlgdec & 0x0f;
        LLSET(OB_SPEC(DLGDEC), obspec);

        obspec = LLGET(OB_SPEC(WINSHADE));
        obspec &= ~0x70;
        obspec |= clrs_wind & 0xf0;
        shade = (clrs_wind & 0xf0) / 0x10;
        LLSET(OB_SPEC(WINSHADE), obspec);

        movs(sizeof(ICONBLK), &G.g_iblist[iconnums[icon]], &local);
        local.ib_ptext = ADDR(&iconstrs[icon][0]);
        
        curr_fore = (my_col_info[icon] & 0xff00) / 0x100;
        curr_back = my_col_info[icon] & 0x00ff;
        if ( (curr_fore == 0) && (curr_back == 0) ) curr_fore = 1;

        LLSET(OB_SPEC(ICNFG), (LLGET(OB_SPEC(ICNFG)) & ~0xf) | curr_fore);
        LLSET(OB_SPEC(ICNBG), (LLGET(OB_SPEC(ICNBG)) & ~0xf) | curr_back);
        
        local.ib_ptext = ADDR(&iconstrs[icon][0]);

        LWSET(OB_X(ADCICN), (LWGET(OB_WIDTH(ICNWIN))-LWGET(OB_WIDTH(ADCICN)))/2);
        LWSET(OB_Y(ADCICN), (LWGET(OB_HEIGHT(ICNWIN))-LWGET(OB_HEIGHT(ADCICN)))/2);

        LLSET(OB_SPEC(ADCICN), ADDR(&local));

        objc_offset(tree, ICNWIN, &iwx, &iwy);
        iwh = LWGET(OB_HEIGHT(ICNWIN));
        iww = LWGET(OB_WIDTH(ICNWIN));

        show_hide(FMD_START, tree);
        draw_cntrls(tree, &local);
        done = FALSE;

        while (!done)
        {
                touchob = form_do(tree, 0);
                touchob &= 0x7fff;
                switch (touchob)
                {
                        case CLROK:
                        case CLRCAN:
                          LWSET(OB_STATE(touchob), LWGET(OB_STATE(touchob)) & ~SELECTED);
                          done = touchob;
                          break;
                        case ICNFG:
                        case ICNBG:
                        case WINCOL1:
                        case DLGDEC:
                          ask_colour(tree, touchob);
                          draw_cntrls(tree, &local);
                          if (touchob == DLGDEC)
                                my_col_info[10] = (LLGET(OB_SPEC(DLGDEC)) & 0x0f);
                          else if (touchob == WINCOL1)
                          {
                                my_col_info[9] = (LLGET(OB_SPEC(WINCOL1)) & 0x0f);
                                my_col_info[9] |= (LLGET(OB_SPEC(WINSHADE)) & 0x70);
                          }
                          else
                          {
                                my_col_info[icon] = (LLGET(OB_SPEC(ICNFG)) & 0x0f) * 0x100;
                                my_col_info[icon] |= LLGET(OB_SPEC(ICNBG)) & 0x0f;
                          }
                          break;
                        case ICNDN:
                          icon += 2;
                        case ICNUP:
                          icon--;
                          if (icon < 0) icon = 0;
                          if (icon > 8) icon = 8;
                          movs(sizeof(ICONBLK), &G.g_iblist[iconnums[icon]], &local);
                          local.ib_ptext = ADDR(&iconstrs[icon][0]);
                          curr_fore = (my_col_info[icon] & 0xff00) / 0x100;
                          curr_back = my_col_info[icon] & 0x00ff;
                          if ( (curr_fore == 0) && (curr_back == 0) ) curr_fore = 1;
                          LLSET(OB_SPEC(ICNFG), (LLGET(OB_SPEC(ICNFG)) & ~0xf) | curr_fore);
                          LLSET(OB_SPEC(ICNBG), (LLGET(OB_SPEC(ICNBG)) & ~0xf) | curr_back);
                        
                          draw_cntrls(tree, &local);
                          break;
                        case WINSHDL:
                          shade += 2;
                        case WINSHDM:
                          shade--;
                          if (shade < 0) shade = 0;
                          if (shade > 7) shade = 7;
                          obspec = LLGET(OB_SPEC(WINSHADE));
                          obspec &= ~0x70;
                          obspec |= (shade * 0x10);
                          LLSET(OB_SPEC(WINSHADE), obspec);
                          draw_cntrls(tree, &local);
                          my_col_info[9] = (LLGET(OB_SPEC(WINCOL1)) & 0x0f);
                          my_col_info[9] |= (LLGET(OB_SPEC(WINSHADE)) & 0x70);
                          break;
                   }
        }

        show_hide(FMD_FINISH, tree);

        if (done == CLROK)
        {
          for (i=0; i<8; i++)
            col_info[i] = my_col_info[i];
          clrs_wind = (BYTE) (my_col_info[9] & 0x00ff);
          clrs_dlgdec = (BYTE) my_col_info[10] & 0x0f;
          if (LWGET(OB_STATE(HIDEDEC)) & SELECTED)
            clrs_dlgdec |= 0xf0;
          change_bars();
          win_bdall();
          win_shwall();
        }

        return(FALSE);
}

        BYTE
*clrs_write( pcurr )
        BYTE    *pcurr;
{
        WORD    slot, i;

        *pcurr++ = '#';
        *pcurr++ = 'e';         /* 'e' - new extensions use this code   */
        *pcurr++ = 'I';         /* 'IC' - Icon Colouring                */
        *pcurr++ = 'C';

        *pcurr++ = 'W';         /* Window                               */
        pcurr = save_2(pcurr,clrs_wind);
        *pcurr++ = 0x0d;
        *pcurr++ = 0x0a;

        *pcurr++ = '#';
        *pcurr++ = 'e';         /* 'e' - new extensions use this code   */
        *pcurr++ = 'I';         /* 'IC' - Icon Colouring                */
        *pcurr++ = 'C';

        *pcurr++ = 'D';         /* Dialog decorations                   */
        pcurr = save_2(pcurr,clrs_dlgdec);
        *pcurr++ = 0x0d;
        *pcurr++ = 0x0a;

        *pcurr++ = '#';
        *pcurr++ = 'e';         /* 'e' - new extensions use this code   */
        *pcurr++ = 'I';         /* 'IC' - Icon Colouring                */
        *pcurr++ = 'C';

        *pcurr++ = 'I';         /* Icons                                */

        for (slot=0; slot<9; slot++)
        {
          pcurr = save_2(pcurr,LHIBT(col_info[slot]));
          pcurr = save_2(pcurr,LLOBT(col_info[slot]));
        }

        *pcurr++ = 0x0d;
        *pcurr++ = 0x0a;

        return(pcurr);
}

        BYTE
*clrs_read( pcurr )
        BYTE    *pcurr;
{
        WORD    i;
        UWORD   read;

        switch (*pcurr++)
        {
                case 'W':       /* Window       */
                        pcurr = scan_2(pcurr,&clrs_wind);
                        break;
                case 'D':       /* Dialog decorations */
                        pcurr = scan_2(pcurr,&clrs_dlgdec);
                        break;
                case 'I':       /* Icons        */
                        for (i=0; i<9; i++)
                        {
                          pcurr = scan_2(pcurr, &read);
                          col_info[i] = (read & 0x00ff) * 0x100;
                          pcurr = scan_2(pcurr, &read);
                          col_info[i] += (read & 0x00ff);
                        }
                        break;
        }

        return(pcurr);
}



        WORD
settings_app(VOID)
{
        WORD            done, junk;
#if MULTIAPP
	ANODE		*pa;
#endif

        G.g_tail[1] = NULL;
        strcpy(ini_str(STSETAPP), &G.g_cmd[0]);
#if MULTIAPP
        pa = app_afind(FALSE, AT_ISFILE, -1, &G.g_cmd[0], &junk);
        pr_kbytes = (pa ? pa->a_memreq : 256);
        pro_run(TRUE, -1, -1, -1);
#else
        done = pro_run(TRUE, TRUE, -1, -1);
#endif
        return(done);
}
