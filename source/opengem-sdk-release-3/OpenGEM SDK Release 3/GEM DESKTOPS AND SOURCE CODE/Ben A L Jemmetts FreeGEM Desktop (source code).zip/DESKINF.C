/*      DESKINF.C       09/03/84 - 05/29/85     Gregg Morris            */
/*	for 3.0	& 2.1	5/5/86			MDF			*/
/*	merge source	5/27/87  - 5/28/87	mdf			*/
/*      Save on exit    19990515                Ben A L Jemmett         */
/*      Shortcut Info                   19990722               BALJ */
/*      New inf_pref() for tabs         19990918               BALJ */
/*      New inf_folder() for renaming   19991220-22     Ken Mauro       */
/*	Y2K fix in fmt_date, ob_sfcb	20000108	BALJ		*/

/*
*       Copyright 1999, Caldera Thin Clients, Inc.                      
*       This software is licenced under the GNU Public License.         
*       Please see LICENSE.TXT for further information.
*                                                                       
*                  Historical Copyright                                 
*	-------------------------------------------------------------
*	GEM Desktop					  Version 2.3
*	Serial No.  XXXX-0000-654321		  All Rights Reserved
*	Copyright (C) 1985 - 1987		Digital Research Inc.
*	-------------------------------------------------------------
*/

#include <portab.h>
#include <machine.h>
#include <obdefs.h>
#include <taddr.h>
#include <desktop.h>
#include <dos.h>
#include <deskapp.h>
#include <deskfpd.h>
#include <deskwin.h>
#include <infodef.h>
#include <gembind.h>
#include <deskbind.h>

EXTERN WORD	dos_rename();
EXTERN WORD	dos_chmod();
EXTERN VOID	merge_str();
EXTERN WORD	strlen();
EXTERN VOID	bb_fill();
EXTERN VOID	gsx_attr();
EXTERN VOID	gsx_tblt();
EXTERN VOID	gsx_gclip();
EXTERN VOID	gsx_sclip();
EXTERN WORD	form_center();
EXTERN WORD	form_dial();
EXTERN WORD	objc_draw();
EXTERN WORD	menu_click();
EXTERN WORD	form_do();
EXTERN WORD	d_doop();
EXTERN VOID	inf_sset();
EXTERN VOID	fmt_str();
EXTERN VOID	inf_fldset();
EXTERN WORD	inf_what();
EXTERN WORD	graf_mouse();
EXTERN VOID	inf_sget();
EXTERN VOID	unfmt_str();
EXTERN WORD	strcmp();
EXTERN WORD	d_errmsg();
EXTERN VOID	dos_space();
EXTERN VOID	dos_label();
EXTERN WORD	evnt_dclick();
EXTERN WORD	sound();
EXTERN WORD	inf_gindex();
EXTERN BOOLEAN  app_reset();
EXTERN BYTE     *scan_str();

EXTERN BYTE	gl_amstr[];
EXTERN BYTE	gl_pmstr[];

EXTERN LONG	ad_intin;

EXTERN GLOBES	G;

#define SFCB struct sfcb
SFCB
{
	BYTE		sfcb_junk;
	BYTE		sfcb_attr;
	WORD		sfcb_time;
	WORD		sfcb_date;
	LONG		sfcb_size;
	BYTE		sfcb_name[13];
};

/************************************************************************/
/* m y _ i t o a							*/
/************************************************************************/
	VOID
my_itoa(number, pnumstr)
	UWORD		number;
	BYTE		*pnumstr;
{
	WORD		ii;

	for (ii = 0; ii < 2; pnumstr[ii++] = '0');
	pnumstr[2] = NULL;
	if (number > 9)
	  merge_str(pnumstr, "%W", &number);
	else
	  merge_str(pnumstr+1, "%W", &number);
} /* my_itoa */

/*
*	Routine to format DOS style time.
*
*	15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 0
*	<     hh     > <    mm    > <   xx  >
*	hh = binary 0-23
*	mm = binary 0-59
*	xx = binary seconds \ 2 
*
*	put into this form 12:45 pm
*/
	VOID
fmt_time(time, ptime)
	UWORD		time;
	BYTE		*ptime;
{
	WORD		pm, val;

	val = ((time & 0xf800) >> 11) & 0x001f;
	if (G.g_ctimeform)
	{
	  if (val >= 12)
	  {
	    if (val > 12)
	      val -= 12;
	    pm = TRUE;
	  }
	  else
	  {
	    if (val == 0)
	      val = 12;
	    pm = FALSE;
	  }
	}
	my_itoa( val, &ptime[0]);
	my_itoa( ((time & 0x07e0) >> 5) & 0x003f, &ptime[2]);
	if (G.g_ctimeform)
	  strcpy((pm?&gl_pmstr[0]:&gl_amstr[0]), &ptime[4]);
	else
	  strcpy("  ", &ptime[4]);
} /* fmt_time */

/*
*	Routine to format DOS style date.
*	
*	15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 0
*	<     yy          > < mm  > <  dd   >
*	yy = 0 - 119 (1980 - 2099)
*	mm = 1 - 12
*	dd = 1 - 31
*/
	VOID
fmt_date(date, pdate)
	UWORD		date;
	BYTE		*pdate;
{
	if (G.g_cdateform)
	{
	  my_itoa( (date & 0x01e0) >> 5, &pdate[0]);
          my_itoa(date & 0x001f, &pdate[2]);
	}
	else
	{
          my_itoa(date & 0x001f, &pdate[0]);
	  my_itoa( (date & 0x01e0) >> 5, &pdate[2]);
	}
        my_itoa(1980 + (((date & 0xfe00) >> 9) & 0x007f), &pdate[4]);
} /* fmt_date */

	WORD
ob_sfcb(psfcb, pfmt)
	LONG		psfcb;
	BYTE		*pfmt;
{
	SFCB		sf;
	BYTE		*pdst, *psrc;
        BYTE            pdate_str[9], ptime_str[7], psize_str[9];
	WORD		cnt;

	LBCOPY(ADDR(&sf.sfcb_junk), psfcb, sizeof(SFCB));
	pdst = pfmt;
	psrc = &sf.sfcb_name[0];
	*pdst++ = ' ';
	*pdst++ = (sf.sfcb_attr & F_SUBDIR) ? 0x07 : ' ';
	*pdst++ = ' ';
	if (sf.sfcb_attr & F_DESKTOP)
	{
	  *pdst++ = sf.sfcb_junk;
	  *pdst++ = ':';
	  *pdst++ = ' ';
	}
	else
	{
	  while( (*psrc) &&
	         (*psrc != '.') )
	    *pdst++ = *psrc++;
	  while( (pdst - pfmt) < 12 )
	    *pdst++ = ' ';
	  if (*psrc)
	    psrc++;
	  while (*psrc)
	    *pdst++ = *psrc++;
	}
	while( (pdst - pfmt) < 16 )
	  *pdst++ = ' ';
	psrc = &psize_str[0];
	if (sf.sfcb_attr & F_SUBDIR)
	  *psrc = NULL;
	else
	  merge_str(&psize_str[0], "%L", &sf.sfcb_size);
	for(cnt = 8 - strlen(psrc); cnt--; *pdst++ = ' ');
	while (*psrc)
	  *pdst++ = *psrc++;
	*pdst++ = ' ';
	*pdst++ = ' ';
	fmt_date(sf.sfcb_date, &pdate_str[0]);
	psrc = &pdate_str[0];
	for(cnt = 3; cnt--; )
	{
	  *pdst++ = *psrc++;
	  *pdst++ = *psrc++;
	  if (cnt)
	    *pdst++ = '-';
	}

        /* Y2K fix - 20000108, BALJ  */
        *pdst++ = *psrc++;
        *pdst++ = *psrc++;

	*pdst++ = ' ';
	*pdst++ = ' ';
	fmt_time(sf.sfcb_time, &ptime_str[0]);
	psrc = &ptime_str[0];
	for(cnt = 2; cnt--; )
	{
	  *pdst++ = *psrc++;
	  *pdst++ = *psrc++;
	  if (cnt)
	    *pdst++ = ':';
	}
	*pdst++ = ' ';
	strcpy(&ptime_str[4], pdst);
	pdst += 3;
	return(pdst - pfmt);
}	

	WORD
dr_fnode(last_state, curr_state, x, y, w, h, psfcb)
	UWORD		last_state, curr_state;
	WORD		x, y, w, h;
	LONG		psfcb;
{
	WORD		len;

	if ((last_state ^ curr_state) & SELECTED)
	  bb_fill(MD_XOR, FIS_SOLID, IP_SOLID, x, y, w, h);
	else
	{
 	  len = ob_sfcb(psfcb, &G.g_tmppth[0]);
          gsx_attr(TRUE, MD_REPLACE, BLACK);
	  LBWMOV(ad_intin, ADDR(&G.g_tmppth[0]));
	  gsx_tblt(IBM, x, y, len);
          gsx_attr(FALSE, MD_XOR, BLACK);
	}
	return(curr_state);
}

	WORD
dr_code(pparms)
	LONG		pparms;
{
	PARMBLK		pb;
	GRECT		oc;
	WORD		state;

	LBCOPY(ADDR(&pb), pparms, sizeof(PARMBLK));
	gsx_gclip(&oc);
	gsx_sclip(&pb.pb_xc);
	state = dr_fnode(pb.pb_prevstate, pb.pb_currstate,
			 pb.pb_x, pb.pb_y, pb.pb_w, pb.pb_h, pb.pb_parm);
	gsx_sclip(&oc);
	return(state);
}

/*
*	Put up dialog box & call form_do.
*/
	WORD
inf_show(tree, start)
	LONG		tree;
	WORD		start;
{
	WORD		xd, yd, wd, hd;

	form_center(tree, &xd, &yd, &wd, &hd);
	form_dial(FMD_START, 0, 0, 0, 0, xd, yd, wd, hd);
	objc_draw(tree, ROOT, MAX_DEPTH, xd, yd, wd, hd);
	form_do(tree, start);
	form_dial(FMD_FINISH, 0, 0, 0, 0, xd, yd, wd, hd);
	return(TRUE);
}

/*
*	Routine for finishing off a simple ok-only dialog box
*/
	VOID
inf_finish(tree, dl_ok)
	LONG		tree;
	WORD		dl_ok;
{
	inf_show(tree, 0);
	LWSET(OB_STATE(dl_ok), NORMAL);
}

/*
*	Routine to get number of files and folders and stuff them in
*	a dialog box.
*/
	WORD
inf_fifo(tree, dl_fi, dl_fo, ppath)
	LONG		tree;
	WORD		dl_fi, dl_fo;
	BYTE		*ppath;
{
	WORD		junk, more;
	BYTE		nf_str[6], nd_str[6];

	G.g_nfiles = 0x0L;
	G.g_ndirs = 0x0L;
	G.g_size = 0x0L;
	more = d_doop(OP_COUNT, 0x0L, ppath, ppath, &junk, &junk);
	if (!more)
	  return(FALSE);
	G.g_ndirs--;

	merge_str(&nf_str[0], "%L", &G.g_nfiles);
	inf_sset(tree, dl_fi, &nf_str[0]);

	merge_str(&nd_str[0], "%L", &G.g_ndirs);
	inf_sset(tree, dl_fo, &nd_str[0]);
	return(TRUE);
}

	VOID
inf_dttmsz(tree, pf, dl_dt, dl_tm, dl_sz, psize)
	LONG		tree;
	FNODE		*pf;
	WORD		dl_dt, dl_tm, dl_sz;
	LONG		*psize;
{
	BYTE		psize_str[9], ptime_str[7], pdate_str[7];

	fmt_date(pf->f_date, &pdate_str[0]);
	inf_sset(tree, dl_dt, &pdate_str[0]);

	fmt_time(pf->f_time, &ptime_str[0]);
	inf_sset(tree, dl_tm, &ptime_str[0]);

	merge_str(&psize_str[0], "%L", psize);
	inf_sset(tree, dl_sz, &psize_str[0]);
}

/************************************************************************/
/* i n f _ f i l e							*/
/************************************************************************/
	WORD
inf_file(ppath, pfnode)
	BYTE		*ppath;
	FNODE		*pfnode;
{
	LONG		tree;
	WORD		attr, more, nmidx;
	BYTE		poname[13], pnname[13];

	tree = G.a_trees[ADFILEIN];

	strcpy(ppath, &G.g_srcpth[0]);
	strcpy(ppath, &G.g_dstpth[0]);
	nmidx = 0;
	while (G.g_srcpth[nmidx] != '*')
	  nmidx++;

	fmt_str(&pfnode->f_name[0], &poname[0]);

	inf_sset(tree, FINAME, &poname[0]);

	inf_dttmsz(tree, pfnode, FIDATE, FITIME, FISIZE, &pfnode->f_size);

	inf_fldset(tree, FIRONLY, pfnode->f_attr, F_RDONLY,SELECTED, NORMAL);
	inf_fldset(tree, FIRWRITE, pfnode->f_attr, F_RDONLY,NORMAL,SELECTED);

	inf_show(tree, 0);
					/* now find out what happened	*/
						/* was it OK or CANCEL?	*/
	if ( inf_what(tree, FIOK, FICNCL) )
	{
	  graf_mouse(HGLASS, 0x0L);

	  more = TRUE;
	  inf_sget(tree, FINAME, &pnname[0]);
	  				/* unformat the strings		*/
	  unfmt_str(&poname[0], &G.g_srcpth[nmidx]);
	  unfmt_str(&pnname[0], &G.g_dstpth[nmidx]);
						/* do the DOS rename	*/
	  if ( !strcmp(&G.g_srcpth[nmidx], &G.g_dstpth[nmidx]) )
	  {
	    dos_rename(ADDR(&G.g_srcpth[0]), ADDR(&G.g_dstpth[0]));
	    if ( (more = d_errmsg()) != 0 )
	      strcpy(&G.g_dstpth[nmidx], &pfnode->f_name[0]);
	  } /* if */
					/* update the attributes	*/
	  attr = pfnode->f_attr;
	  if (LWGET(OB_STATE(FIRONLY)) & SELECTED)
	    attr |= F_RDONLY;
	  else
	    attr &= ~F_RDONLY;
	  if ( (BYTE) attr != pfnode->f_attr )
	  {
	    dos_chmod(ADDR(&G.g_dstpth[0]), F_SETMOD, attr);
	    if ( (more = d_errmsg()) != 0 )
	      pfnode->f_attr = attr;
	  }
	  graf_mouse(ARROW, 0x0L);
	  return(more);
	}
	else
	  return(FALSE);
} /* inf_file */

/************************************************************************/
/* i n f _ f o l d e r							*/
/************************************************************************/

	WORD
inf_folder(ppath, pfnode) /* v2 - Ken, 19991220-22.  Renaming folders.  */
	BYTE		*ppath;
	FNODE		*pfnode;
{
	LONG		tree;
        WORD            more, nmidx;
	BYTE		poname[13], pnname[13];
	BYTE		*pname, fname[13];

        /* NB - BALJ - 19991223 - modified to return rebuild flag       */

	tree = G.a_trees[ADFOLDIN];

	strcpy(ppath, &G.g_srcpth[0]);
	strcpy(ppath, &G.g_dstpth[0]);

	nmidx = 0;
	while (G.g_srcpth[nmidx] != '*')
		nmidx++;
	fmt_str(&pfnode->f_name[0], &poname[0]);
	inf_sset(tree, FOLNAME, &poname[0]);

	pname = &G.g_srcpth[0];
	while (*pname != '*')
		pname++;

	pname = strcpy(&pfnode->f_name[0], pname);
	strcpy("\\*.*", pname-1);

	more = inf_fifo(tree, FOLNFILE, FOLNFOLD, &G.g_srcpth[0]);

	if (more){
		fmt_str(&pfnode->f_name[0], &fname[0]);
		inf_sset(tree, FOLNAME, &fname[0]);
		inf_dttmsz(tree, pfnode, FOLDATE, FOLTIME, FOLSIZE, &G.g_size);
		}

	LWSET(OB_STATE(FOLOK), NORMAL);
        LWSET(OB_STATE(FOLCAN), NORMAL);

	inf_show(tree, 0);		/* now find out what happened */

        if ( inf_what(tree, FOLOK, FOLCAN) ) /* BALJ - Cancel option. */
        {
          graf_mouse(HGLASS, 0x0L);
          more = TRUE;
          inf_sget(tree, FOLNAME, &pnname[0]);

          unfmt_str(&poname[0], &G.g_srcpth[nmidx]);
          unfmt_str(&pnname[0], &G.g_dstpth[nmidx]);
          if(!strcmp(&G.g_srcpth[nmidx], &G.g_dstpth[nmidx]))
          {
            dos_rename(ADDR(&G.g_srcpth[0]),ADDR(&G.g_dstpth[0]));
            if( (more = d_errmsg()) != 0 )
              strcpy(&G.g_dstpth[nmidx], &pfnode->f_name[0]);
          }
          graf_mouse(ARROW, 0x0L);
          return(TRUE);
        }
        else return(FALSE);

} /* inf_folder2 */


/*        WORD
inf_folder(ppath, pf)
	BYTE		*ppath;
	FNODE		*pf;
{
	LONG		tree;
	WORD		more;
	BYTE		*pname, fname[13];

	graf_mouse(HGLASS, 0x0L);	

	tree = G.a_trees[ADFOLDIN];

	strcpy(ppath, &G.g_srcpth[0]);
	pname = &G.g_srcpth[0];
	while (*pname != '*')
	  pname++;
	pname = strcpy(&pf->f_name[0], pname);
	strcpy("\\*.*", pname-1);

	more = inf_fifo(tree, FOLNFILE, FOLNFOLD, &G.g_srcpth[0]);

	graf_mouse(ARROW, 0x0L);
	if (more)
	{
	  fmt_str(&pf->f_name[0], &fname[0]);
	  inf_sset(tree, FOLNAME, &fname[0]);

	  inf_dttmsz(tree, pf, FOLDATE, FOLTIME, FOLSIZE, &G.g_size);
	  inf_finish(tree, FOLOK);
	}
	return(TRUE);
} /* inf_folder */

/************************************************************************/
/* i n f _ d i s k							*/
/************************************************************************/
	WORD
inf_disk(dr_id)
	BYTE		dr_id;
{
	LONG		tree;
	LONG		total, avail;
	WORD		more;
	BYTE		puse_str[9], pav_str[9], plab_str[12];
	BYTE		drive[2];
	
	graf_mouse(HGLASS, 0x0L);
	tree = G.a_trees[ADDISKIN];

	drive[0] = dr_id;
	drive[1] = NULL;
	G.g_srcpth[0] = drive[0];
	strcpy(":\\*.*", &G.g_srcpth[1]);

	more = inf_fifo(tree, DINFILES, DINFOLDS, &G.g_srcpth[0]);

	graf_mouse(ARROW, 0x0L);
	if (more)
	{
	  dos_space(dr_id - 'A' + 1, &total, &avail);
	  dos_label(dr_id - 'A' + 1, &plab_str[0]);

	  inf_sset(tree, DIDRIVE, &drive[0]);
	  inf_sset(tree, DIVOLUME, &plab_str[0]);

	  merge_str(&puse_str[0], "%L", &G.g_size);
	  inf_sset(tree, DIUSED, &puse_str[0]);
	  
	  merge_str(&pav_str[0], "%L", &avail);
	  inf_sset(tree, DIAVAIL, &pav_str[0]);

	  inf_finish(tree, DIOK);
	}
	return(TRUE);
} /* inf_disk */

/*
*       Routine to select new tab in preferences dialog - BALJ 19990918
*/
        VOID
pref_tab( tab)
        WORD            tab;
{
        LONG            tree;
        WORD            panel;
	WORD		xd, yd, wd, hd;

        switch (tab)
        {
          case PTABDESK:
            panel = DESKPREF;
            break;
          case PTABSYS:
            panel = SYSPREF;
            break;
          case PTABCOMP:
            panel = COMPPREF;
            break;
          default:
            return;
        }
        tree = G.a_trees[NEWPREF];

        /* Deselect all tabs                                          */
        LWSET(OB_STATE(PTABDESK), NORMAL);
        LWSET(OB_STATE(PTABSYS), NORMAL);
        LWSET(OB_STATE(PTABCOMP), NORMAL);

        /* Hide all panels                                            */
        LWSET(OB_FLAGS(DESKPREF), HIDETREE);
        LWSET(OB_FLAGS(SYSPREF), HIDETREE);
        LWSET(OB_FLAGS(COMPPREF), HIDETREE);

        /* Select the right tab and show the panel                    */

        /* The SELECTED attribute if fine on old AESes.  On a newer 3D */
        /* one, however, it doesn't look right.  I messed around with  */
        /* having flat and raised tabs using the USECOLOURCAT and FLAG3D */
        /* flags, but it didn't work properly, so I'll use this for now. */
        LWSET(OB_STATE(tab), SELECTED);
        LWSET(OB_FLAGS(panel), USECOLOURCAT);

        /* Now we redraw the tabs and the relevant panel, then put the  */
        /* selected tab 'on top' of the panel.                          */
        form_center(tree, &xd, &yd, &wd, &hd);
        objc_draw(tree, SPTABS, MAX_DEPTH, xd, yd, wd, hd);
        objc_draw(tree, SPPANELS, MAX_DEPTH, xd, yd, wd, hd);
        objc_draw(tree, tab, MAX_DEPTH, xd, yd, wd, hd);
}


/*
*	Set preferences dialog.
*/
	WORD
inf_pref()
{
	LONG		tree;
	WORD		cyes, cno, i;
	WORD		sndefpref;
        WORD            rbld, touchob;
        BOOLEAN         done;
	WORD		xd, yd, wd, hd;
        WORD            showntab;

        tree = G.a_trees[NEWPREF];
        pref_tab(PTABDESK);
        showntab = PTABDESK;

	rbld = FALSE;

        /* Fill in current settings on Desktop tab      */
          cyes = (G.g_cdelepref) ? SELECTED : NORMAL;
          cno = (G.g_cdelepref) ? NORMAL : SELECTED;
          LWSET(OB_STATE(DPDELYES), cyes);
          LWSET(OB_STATE(DPDELNO), cno);

          cyes = (G.g_ccopypref) ? SELECTED : NORMAL;
          cno = (G.g_ccopypref) ? NORMAL : SELECTED;
          LWSET(OB_STATE(DPCOPYES), cyes);
          LWSET(OB_STATE(DPCOPNO), cno);

          cyes = (G.g_covwrpref) ? SELECTED : NORMAL;
          cno = (G.g_covwrpref) ? NORMAL : SELECTED;
          LWSET(OB_STATE(DPOWYES), cyes);
          LWSET(OB_STATE(DPOWNO), cno);

          cyes = (G.g_saveonexit) ? SELECTED : NORMAL;
          cno = (G.g_saveonexit) ? NORMAL : SELECTED;
          LWSET(OB_STATE(DPSOEYES), cyes);
          LWSET(OB_STATE(DPSOENO), cno);

          cyes = (G.g_trashinwin) ? SELECTED : NORMAL;
          cno = (G.g_trashinwin) ? NORMAL : SELECTED;
          LWSET(OB_STATE(DPFTYES), cyes);
          LWSET(OB_STATE(DPFTNO), cno);

          cyes = (G.g_useorigcol) ? SELECTED : NORMAL;
          cno = (G.g_useorigcol) ? NORMAL : SELECTED;
          LWSET(OB_STATE(DPUCYES), cyes);
          LWSET(OB_STATE(DPUCNO), cno);

        /* Fill in current settings on System tab      */
          cyes = (G.g_cmclkpref) ? SELECTED : NORMAL;
          cno = (G.g_cmclkpref) ? NORMAL : SELECTED;
          LWSET(OB_STATE(SPMCLK), cyes);
          LWSET(OB_STATE(SPMNCLK), cno);

          cyes = (G.g_ctimeform) ? SELECTED : NORMAL;
          cno = (G.g_ctimeform) ? NORMAL : SELECTED;
          LWSET(OB_STATE(SPTIM12), cyes);
          LWSET(OB_STATE(SPTIM24), cno);

          cyes = (G.g_cdateform) ? SELECTED : NORMAL;
          cno = (G.g_cdateform) ? NORMAL : SELECTED;
          LWSET(OB_STATE(SPDATMM), cyes);
          LWSET(OB_STATE(SPDATDD), cno);

          for(i=0; i<5; i++)
            LWSET(OB_STATE(SYSDC1+i), NORMAL);

          G.g_cdclkpref = evnt_dclick(0, FALSE);
          LWSET(OB_STATE(SYSDC1+G.g_cdclkpref), SELECTED);

          sndefpref = !sound(FALSE, 0xFFFF, 0);

          cyes = (sndefpref) ? SELECTED : NORMAL;
          cno = (sndefpref) ? NORMAL : SELECTED;
          LWSET(OB_STATE(SPSNDON), cyes);
          LWSET(OB_STATE(SPSNDOFF), cno);

        /* Fill in current settings on Compatability tab      */
          cyes = (G.g_detdrives) ? SELECTED : NORMAL;
          cno = (G.g_detdrives) ? NORMAL : SELECTED;
          LWSET(OB_STATE(CPDDYES), cyes);
          LWSET(OB_STATE(CPDDNO), cno);

          cyes = (G.g_probedrives) ? SELECTED : NORMAL;
          cno = (G.g_probedrives) ? NORMAL : SELECTED;
          LWSET(OB_STATE(CPPDYES), cyes);
          LWSET(OB_STATE(CPPDNO), cno);

        /* Display the dialog                           */

	form_center(tree, &xd, &yd, &wd, &hd);
	form_dial(FMD_START, 0, 0, 0, 0, xd, yd, wd, hd);
	objc_draw(tree, ROOT, MAX_DEPTH, xd, yd, wd, hd);

        done = FALSE;

        while( !done )
        {
          touchob = form_do(tree, 0);
          touchob &= 0x7fff;
          switch (touchob)
          {
            case PTABDESK:
            case PTABSYS:
            case PTABCOMP:
              if (touchob != showntab)
                pref_tab(touchob);
              showntab = touchob;
              break;

            case CPREPAIR:  /* Special case - 'repair' button */
              if ( !app_reset(FALSE) )
                showntab = showntab;

              LWSET(OB_STATE(CPREPAIR), NORMAL);
              objc_draw(tree, CPREPAIR, MAX_DEPTH, xd, yd, wd, hd);
              break;

            case PREFOK:
            case PREFCAN:
              done = TRUE;
              break;
          }
        }
	form_dial(FMD_FINISH, 0, 0, 0, 0, xd, yd, wd, hd);
        LWSET(OB_STATE(touchob), NORMAL);

        if ( touchob == PREFOK )
	{
          G.g_cdelepref = inf_what(tree, DPDELYES, DPDELNO);
          G.g_ccopypref = inf_what(tree, DPCOPYES, DPCOPNO);
          G.g_covwrpref = inf_what(tree, DPOWYES, DPOWNO);
          G.g_saveonexit = inf_what(tree, DPSOEYES, DPSOENO);   /* BALJ - SOE */
          G.g_trashinwin = inf_what(tree, DPFTYES, DPFTNO);
          G.g_useorigcol = inf_what(tree, DPUCYES, DPUCNO);

          G.g_cmclkpref = inf_what(tree, SPMCLK, SPMNCLK);
	  G.g_cmclkpref = menu_click(G.g_cmclkpref, TRUE);

          G.g_cdclkpref = inf_gindex(tree, SYSDC1, 5);
	  G.g_cdclkpref = evnt_dclick(G.g_cdclkpref, TRUE);
          sndefpref = inf_what(tree, SPSNDON, SPSNDOFF);
					/* changes if file display? */
          cyes = inf_what(tree, SPTIM12, SPTIM24);
	  if (G.g_ctimeform != cyes)
	  {
	    rbld = (G.g_iview == V_TEXT);
	    G.g_ctimeform = cyes;
	  }
          cyes = inf_what(tree, SPDATMM, SPDATDD);
	  if (G.g_cdateform != cyes)
	  {
	    rbld |= (G.g_iview == V_TEXT);
	    G.g_cdateform = cyes;
	  }
	  sound(FALSE, !sndefpref, 0);

          G.g_detdrives = inf_what(tree, CPDDYES, CPDDNO);
          G.g_probedrives = inf_what(tree, CPPDYES, CPPDNO);
	}
	return(rbld);
} /* inf_pref */

/*
*	Open application icon
*/
	WORD
opn_appl(papname, papparms, pcmd, ptail)
	BYTE		*papname, *papparms;
	BYTE		*pcmd, *ptail;
{
	LONG		tree;
	BYTE		poname[13];

	tree = G.a_trees[ADOPENAP];

	fmt_str(papname, &poname[0]);

	inf_sset(tree, APPLNAME, &poname[0]);

	inf_sset(tree, APPLPARM, papparms);

	inf_show(tree, APPLPARM);
					/* now find out what happened	*/
	if ( inf_what(tree, APPLOK, APPLCNCL) )
	{
	  inf_sget(tree, APPLNAME, &poname[0]);
	  unfmt_str(&poname[0], pcmd);
	  inf_sget(tree, APPLPARM, ptail);
	  return(TRUE);
	}
	else
	  return(FALSE);
}

/************************************************************************/
/* i n f _ s h r t                                                      */
/************************************************************************/
/* Displays and handles shortcut information dialog.  BALJ, 19990722.   */
/************************************************************************/
        WORD
inf_shrt(pa)
        ANODE   *pa;
{
        LONG    tree;
        BYTE    newappl[13], newdata[64];

        tree = G.a_trees[ADSHRTIN];

        /* Fill in existing values              */
        inf_sset(tree, SILABEL, &pa->a_pappl[0]);
        inf_sset(tree, SIFILES, &pa->a_pdata[0]);

        inf_show(tree, 0);
        if ( inf_what(tree, SIOK, SICANCEL) )
        {
                /* Change the shortcut          */
                inf_sget(tree, SILABEL, &newappl);
                inf_sget(tree, SIFILES, &newdata);
                scan_str(&newappl, &pa->a_pappl);
                scan_str(&newdata, &pa->a_pdata);
                return(TRUE);
        }
        return(FALSE);
}

/************************************************************************/
/* i n f _ t r s h                                                      */
/************************************************************************/
/* Displays and handles trashcan information dialog.  BALJ, 19990723.   */
/************************************************************************/
        WORD
inf_trsh(pa)
        ANODE   *pa;
{
        LONG    tree;
        BYTE    newappl[13];

        tree = G.a_trees[ADTRSHIN];

        /* Fill in existing values              */
        inf_sset(tree, TILABEL, &pa->a_pappl[0]);

        inf_show(tree, 0);
        if ( inf_what(tree, TIOK, TICANCEL) )
        {
                /* Change the shortcut          */
                inf_sget(tree, TILABEL, &newappl);
                scan_str(&newappl, &pa->a_pappl);
                return(TRUE);
        }
        return(FALSE);
}

