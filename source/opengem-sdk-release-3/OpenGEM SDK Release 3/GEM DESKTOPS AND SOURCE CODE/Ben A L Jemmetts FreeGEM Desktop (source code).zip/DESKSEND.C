/************************************************************************/
/* DESKSEND.C - Desktop 'Send To' menu code                             */
/* 19991219 - BALJ      - Created                                       */
/* 19991221 - BALJ      - DESKTOP.INF code - new extension system       */
/* 19991222 - BALJ      - Send To menu code complete.  Open With added. */
/************************************************************************/
/* This code is (C)opyright Ben A L Jemmett, 1999.                      */
/* This code is covered by the GNU General Public License.              */
/* Please see the enclosed LICENSE.TXT for more details.                */
/************************************************************************/

/************************************************************************/
/*** Compile-time options                                               */
/************************************************************************/

/* #define this line if you don't want the gaps in your Send To list to */
/*    be preserved when saved to DESKTOP.INF                            */

#define NOEMPTYINFS

/* #define this line if you want drives to be passed to apps as x:\, as */
/*    opposed to x:.                                                    */
/* #define DRIVEROOTS   */

/************************************************************************/
/*** Common Desktop include files                                       */
/************************************************************************/

#include <portab.h>
#include <machine.h>
#include <obdefs.h>
#include <taddr.h>
#include <dos.h>
#include <gembind.h>
#include <desktop.h>
#include <deskapp.h>
#include <deskfpd.h>
#include <deskwin.h>
#include <infodef.h>
#include <deskbind.h>
#include <desksend.h>

/************************************************************************/
/*** External routines                                                  */
/************************************************************************/

EXTERN VOID	show_hide();
EXTERN WORD	form_do();
EXTERN VOID     not_implemented();
EXTERN WORD	menu_text();
EXTERN WORD	menu_ienable();
EXTERN WORD	rsrc_gaddr();
EXTERN WORD	mul_div();
EXTERN WORD     min();
EXTERN WORD	max();
EXTERN UWORD	inside();
EXTERN BYTE	*scasb();
EXTERN WORD	sound();
EXTERN WORD	strchk();
EXTERN WORD	objc_draw();
EXTERN WORD	form_center();
EXTERN WORD	graf_mkstate();
EXTERN VOID 	ob_actxywh();
EXTERN WORD	wind_update();
EXTERN WORD	graf_slidebox();
EXTERN ANODE	*app_afind();
EXTERN WORD	win_isel();
EXTERN ANODE    *i_find();
EXTERN WNODE	*win_find();
EXTERN VOID	fpd_parse();
EXTERN WORD     do_aopen();
EXTERN WORD     strcmp();
EXTERN WORD     form_alert();
EXTERN VOID	inf_sset();
EXTERN VOID	inf_sget();

/************************************************************************/
/*** External variables                                                 */
/************************************************************************/

EXTERN WORD	gl_hbox;
EXTERN GLOBES	G;

/************************************************************************/
/*** Internally global variables and compiler macros                    */
/************************************************************************/

#define NUM_AFILES NUM_ANODES+1         /* Max. number of names in list */
#define NUM_FSNAME  8                   /* Number of on-screen names    */
#define LEN_FSNAME 16                   /* Length of each name          */

GLOBAL STNODE   sendto_list[8];         /* The list of Send To entries  */
GLOBAL LONG     sad_estsl;              /* Address of empty item string */
GLOBAL BYTE     trun_mode;              /* Menu truncation mode         */
                                        /* 0 none, 1 lowest, 2 all      */
GLOBAL LONG     sad_tmp1;               /* Temporary buffer 1 address   */
GLOBAL BYTE     sgl_tmp1[LEN_FSNAME];   /* Temporary buffer 1           */
GLOBAL LONG     sad_tmp2;               /* Temporary buffer 2 address   */
GLOBAL BYTE     sgl_tmp2[LEN_FSNAME];   /* Temporary buffer 2           */
GLOBAL BYTE     *sg_fslist[NUM_AFILES]; /* List of pointers to names    */
GLOBAL BYTE     sg_fsnames[LEN_FSNAME * NUM_ANODES]; /* List of names   */
GLOBAL WORD     sanode;                 /* Current name in whole list   */
GLOBAL WORD     sapp;                   /* Current name in shown list   */
GLOBAL WORD     acount;                 /* Count of names in list       */
GLOBAL WORD     slinesread;             /* Number of .INF entries read  */

/************************************************************************/
/*** Utility routines                                                   */
/************************************************************************/

        VOID
my_beep(VOID)
{
        /*** Two tone error beep ****************************************/
        sound (TRUE, 233, 5);           /* Bb   */
        sound (TRUE, 185, 10);          /* Gb   */
}

        ANODE
*send_afind(index)
        WORD    index;
{
        ANODE   *pa;
        BYTE    *abuf1;
        BYTE    buf1[13];
        WORD    i, isapp;

        /*** Routine to look up a matching ANODE ************************/

        abuf1 = &buf1[0];

        for(i=0; i<13; i++)
          if (sendto_list[index].appl[i])
            *abuf1++ = sendto_list[index].appl[i];
        *abuf1++ = 0;

        pa = app_afind(FALSE, AT_ISFILE, -1, &buf1[0], &isapp);

        return(pa);
}

        WORD
send_to(index)
        WORD    index;
{
        ANODE           *pa, *newpa;
        WNODE           *pw;
        FNODE           *pf;
	WORD		isapp;
	WORD		curr;
	WORD		drv;
        WORD            done;
        BYTE            path[66], name[9], ext[4];
        WORD            isdrv;
        BYTE            drvlet[4];

        /*** Routine to send document to selected application ***********/

        if (sendto_list[index].type == ST_EMPTY)
        {
          /* What the f - hey hey!  That's empty!  Don't call that!     */
          my_beep();
          return(FALSE);
        }

        done = FALSE;

        /* Step 1 - Find the name of the highlighted document           */
	curr = win_isel(G.g_screen, G.g_croot, 0);
	pa = i_find(G.g_cwin, curr, &pf, &isapp);
	pw = win_find(G.g_cwin);

        isdrv = FALSE;

        if ( pa->a_type == AT_ISDISK )
        {
          drvlet[0] = (BYTE) pa->a_letter;
          drvlet[1] = ':';
#ifdef DRIVEROOTS
          drvlet[2] = '\\';
          drvlet[3] = 0;
#else
          drvlet[2] = 0;
#endif
          isdrv = TRUE;
        }

        if ( pf )
          fpd_parse(&pw->w_path->p_spec[0],&drv,&path[0],&name[0],&ext[0]);
        else if (!isdrv)
        {
          my_beep();
          return(FALSE);
        }

        /* Step 2 - Catch That ANODE!                                   */
        newpa = send_afind(index);

        if (newpa)
        {
          pa = newpa;
          isapp = FALSE;
          /* Step 3 - Open the ANODE with that filename                   */
          done = do_aopen(pa,isapp,curr,drv,&path[0], 
                          (isdrv ? &drvlet[0] : &pf->f_name[0]) );
        }
        return(done);
}

        VOID
send_mrst(VOID)
{
        WORD    item, newht;
        LONG    tree;

        /*** Routine to return menu to default uncollapsed state ********/

        tree = G.a_trees[ADMENU];

        /* Height of uncollapsed menu is 10 items                       */
        newht = 10 * LWGET(OB_HEIGHT(ESTMITEM));
        LWSET(OB_HEIGHT(ESTMITEM-1), newht);

        /* Loop through all objects, setting in the right order         */
        for (item = ESTMITEM; item <=STE8ITEM; item++)
        {
          LWSET(OB_NEXT(item), item+1);
          LWSET(OB_Y(item), (item-ESTMITEM)*LWGET(OB_HEIGHT(ESTMITEM)));
        }

        /* Set the head and tail of the tree properly                   */
        LWSET(OB_TAIL(ESTMITEM-1), STE8ITEM);
        LWSET(OB_NEXT(STE8ITEM), ESTMITEM-1);
}

        VOID
send_tall(VOID)
{
        WORD    newht, item, count, previtem;
        LONG    tree;

        /*** Routine to do a full re-org of the menu - for 'full' mode **/

        tree = G.a_trees[ADMENU];
        newht = LWGET(OB_HEIGHT(ESTMITEM-1));

        /* Count up the filled slots first                              */
        count =0;
        for (item=0; item<8; item++)
          if (sendto_list[item].type != ST_EMPTY)
            count++;

        if (count == 0)
        {     /* No filled slots.  Truncate menu completely.            */
          newht = LWGET(OB_HEIGHT(ESTMITEM));
          LWSET(OB_TAIL(ESTMITEM-1), ESTMITEM);
          LWSET(OB_NEXT(ESTMITEM), ESTMITEM-1);
        } else {        /* Some filled slots.  Loop and arrange items   */
          newht = (count + 2) * LWGET(OB_HEIGHT(ESTMITEM));
          previtem = -1;
          count = 2;

          for (item=0; item<8; item++)
            if (sendto_list[item].type != ST_EMPTY)
            {
              LWSET(OB_Y(STE1ITEM+item), count++ * LWGET(OB_HEIGHT(ESTMITEM)));
              LWSET(OB_NEXT(STE1ITEM+previtem), STE1ITEM+item);
              previtem = item;
            }
          LWSET(OB_NEXT(STE1ITEM+previtem), ESTMITEM-1);
          LWSET(OB_TAIL(ESTMITEM-1), STE1ITEM+previtem);
        }
        /* All done.  Set menu height.                                  */
        LWSET(OB_HEIGHT(ESTMITEM - 1), newht);
}

        VOID
send_tsome(VOID)
{
        WORD    newht, done, item;
        LONG    tree;

        /*** Routine to collapse the lower unused entries in the menu ***/

        tree = G.a_trees[ADMENU];
        newht = 10 * LWGET(OB_HEIGHT(ESTMITEM));

        done = FALSE;
        item = 8;

        while (!done)
        {
          item--;
                /* Loop through the 8 slots looking for the             */
                /* last empty one, and stop at the top.                 */
          if ((sendto_list[item].type != ST_EMPTY) || item == -1)
            done = TRUE;
          else
          {
                /* Cut off the current item                             */
            newht -= LWGET(OB_HEIGHT(STE1ITEM+item));
            LWSET(OB_TAIL(ESTMITEM-1), STE1ITEM+item-1);
            LWSET(OB_NEXT(STE1ITEM+item-1), ESTMITEM-1);
          }
        }

        if (item == -1) /* No filled slots - remove seperator           */
        {
          newht -= LWGET(OB_HEIGHT(STE1ITEM-1));
          LWSET(OB_TAIL(ESTMITEM-1), ESTMITEM);
          LWSET(OB_NEXT(ESTMITEM), ESTMITEM-1);
        }

        /* Set the height of the menu itself                            */
        LWSET(OB_HEIGHT(ESTMITEM - 1), newht);

}

        VOID
send_trun(VOID)
{

        /*** Routine to call the appropriate truncation routine         */

        /* First, reset menu to full list                               */
        send_mrst();

        /* Now call appropriate routine to truncate menu                */
        switch (trun_mode)
        {
          case 0:       /* No truncation, just return                   */
            break;
          case 1:
            send_tsome();       /* Truncate the lower lines             */
            break;
          case 2:
            send_tall();        /* Truncate 'Em All                     */
            break;
        }
}

/************************************************************************/
/*** Application selector handling routines (adapted from DESKIACC.C)   */
/************************************************************************/
	WORD
send_comp()
{
	WORD		chk;

        /*** Routine to compare the temp buffers during sorting *********/

        if ( (sgl_tmp1[0] == ' ') &&
             (sgl_tmp2[0] == ' ') )
	{
          chk = strchk( scasb(&sgl_tmp1[0], '.'), 
                        scasb(&sgl_tmp2[0], '.') );
	  if ( chk )
	    return( chk );
	}
        return ( strchk(&sgl_tmp1[0], &sgl_tmp2[0]) );
}


	VOID
send_elev(tree, currtop, count)
	LONG		tree;
	WORD		currtop;
	WORD		count;
{
	WORD		h,y,th;

        /*** Routine to correctly size & position the thumb/elevator ****/

	y = 0;
        th = h = LWGET(OB_HEIGHT(ESTMABAR));  
	if ( count > NUM_FSNAME)
	{
	  h = mul_div(NUM_FSNAME, h, count);
          h = max(gl_hbox/2, h);                 /* min size elevator   */
	  y = mul_div(currtop, th-h, count-NUM_FSNAME);
	}
        LWSET(OB_Y(ESTMASLD), y);
        LWSET(OB_HEIGHT(ESTMASLD), h);
}

	VOID
send_mvnames(tree, start, num)
	LONG		tree;
	WORD		start;
	WORD		num;
{
	WORD		i, j, k;
	WORD		len;

        /*** Routine to copy the visible app names into the selector ****/

	for (i=0; i<num; i++)
	{
          LSTCPY(sad_tmp1, ADDR(sg_fslist[i+start]));
	  len = 0;
          while (sgl_tmp1[len] != '.')
	    len++;
	  if (len < 8)				/* blank pad in middle	*/
	  {
	    for (j=11, k=len+3; j > 7; j--, k--)
              sgl_tmp1[j] = sgl_tmp1[k];
	    for (j=len; j < 8; j++)
              sgl_tmp1[j] = ' ';
	  }
          LSTCPY(LLGET(OB_SPEC(ESTMA1+i)), sad_tmp1);
	}
}

	WORD
send_names(tree)
	LONG		tree;
{
        WORD            len, ret;
	WORD		i, j, gap;
	WORD		thefile;
	BYTE		*ptr, *temp;
	ANODE		*pa;

        /*** Routine to initialise the app. selector and names list *****/

        thefile = 0;
        ptr = &sg_fsnames[0];
        sad_tmp1 = ADDR(&sgl_tmp1[0]);
        sad_tmp2 = ADDR(&sgl_tmp2[0]);

        ret = TRUE;

        /* Loop through all ANODEs...                                   */
        for(pa = G.g_ahead; pa; pa = pa->a_next)
        {
          if ( pa->a_type == AT_ISFILE )        /* Looking for FILEs... */
            if ( (*pa->a_pappl != '*') &&       /* That aren't wild...  */
                 (*pa->a_pappl != '?') &&
                 (*pa->a_pappl != NULL) )       /* ... or blank.        */
            {
                /* We got one!  Copy it into the list if there's room   */
              if ( ret )
              {
                len = LSTCPY(ADDR(sg_fslist[thefile] = ptr), ADDR(pa->a_pappl));
                ptr += len+1;
              }

              if (thefile++ >= NUM_AFILES)
              {
                my_beep();      /* Otherwise, beep.  This should never  */
                                /*   happen unless NUM_AFILES is wrong. */
                ret = FALSE;    /* No more room                         */
              }
            }
        }

        /* Sort the list                                                */
        for(gap = thefile/2; gap > 0; gap /= 2)
	{
	  for(i = gap; i < thefile; i++)
	  {
	    for (j = i-gap; j >= 0; j -= gap)
	    {
              LSTCPY(sad_tmp1, ADDR(sg_fslist[j]));
              LSTCPY(sad_tmp2, ADDR(sg_fslist[j+gap]));
              if ( send_comp() <= 0 )
		break;
              temp = sg_fslist[j];
              sg_fslist[j] = sg_fslist[j+gap];
              sg_fslist[j+gap] = temp;
	    }
	  }
	}

        /* Move the top NUM_FSNAME names into the display now           */
        send_mvnames(tree, 0, min(thefile, NUM_FSNAME));

        /* And return the number of entries                             */
	return(thefile);
}

	WORD
send_scroll(tree, currtop, count, move)
	LONG		tree;
	WORD		currtop;
	WORD		count;
	WORD		move;
{
	WORD		newtop;
        WORD            xd, yd, wd, hd;
        
        /*** Routine to handle the scroll bar ***************************/

        if (count <= NUM_FSNAME)
          return(0);    /* If the files don't fill the list, just exit  */

        /* Move, but then adjust at the top or bottom of the list       */
        newtop = currtop + move;
	newtop = max(newtop, 0);
	newtop = min(newtop, count - NUM_FSNAME);

        /* If we end up not moving, exit                                */
	if (newtop == currtop)
	  return(currtop);

        /* Move the thumb/elevator and names                            */
        send_elev(tree, newtop, count);
        send_mvnames(tree, newtop, NUM_FSNAME);

        /* Redraw the application selector                              */
        form_center(tree, &xd, &yd, &wd, &hd);
        objc_draw(tree, ESTMSLCT, MAX_DEPTH, xd, yd, wd, hd);

        /* Return the new top-of-list                                   */
	return(newtop);
}

/************************************************************************/
/*** Other dialog support routines                                      */
/************************************************************************/

        WORD
send_find( locate )
        WORD    locate;
{
        WORD    curr, i;
        WORD    found;

        /*** Routine to find the specified app in the list **************/

        found = -1;

        for (curr=0; curr<acount; curr++)
        {
          /* Blank any stuff in the buffers already                     */
          for (i=0; i<LEN_FSNAME; i++)
            sgl_tmp1[i] = sgl_tmp2[i] = 0;

          /* Copy the test app name into the buffer                     */
          LSTCPY(sad_tmp1, ADDR(sg_fslist[curr]));
        
          /* Copy the known name into the other buffer                  */
          for (i=0; i<12; i++)
            sgl_tmp2[i] = sendto_list[locate].appl[i];

          /* Blank the last parts of the buffers again                  */
          for (i=12; i<LEN_FSNAME; i++)
            sgl_tmp1[i] = sgl_tmp2[i] = 0;

          if (strcmp(&sgl_tmp1[0], &sgl_tmp2[0]))
            found = curr;
        }

        return(found);
        
}

        VOID
send_cchk()
{
        WORD i;
        LONG tree;
        WORD            xd, yd, wd, hd;

        /*** Routine to clear all checks in the app selector except the */
        /***   selected name                                            */

        tree = G.a_trees[ADSENDED];

        for (i=0; i<8; i++)
          LWSET(OB_STATE(ESTMAC1+i), LWGET(OB_STATE(ESTMAC1+i)) & !CHECKED);

        if (sapp != -1)
          LWSET(OB_STATE(ESTMAC1+sapp), LWGET(OB_STATE(ESTMAC1+sapp)) | CHECKED);

        form_center(tree, &xd, &yd, &wd, &hd);
        objc_draw(tree, ESTMFSBX, MAX_DEPTH, xd, yd, wd, hd);

}

        VOID
send_mupd( redraw )
        BOOLEAN redraw;
{
        BYTE    ii, tempstr[24];
        BYTE    FAR *temp;
        LONG    tree;
        WORD    xd, yd, wd, hd;

        /*** Routine to update the 'menu' in the dialog box *************/

        tree = G.a_trees[ADSENDED];
        for(ii=0; ii<8; ii++)
          switch(sendto_list[ii].type)
          {
            case ST_EMPTY:
              LSTCPY(LLGET(OB_SPEC(ESTME1+ii)), sad_estsl);
              break;
            case ST_APPL:
              temp = (FAR) &tempstr[0];
              *temp++ = ' ';
              *temp++ = ' ';
              strcpy(&sendto_list[ii].name[0], temp);
              temp = (FAR) &tempstr[0];
              LSTCPY(LLGET(OB_SPEC(ESTME1+ii)), temp);
              break;
          }
        if (redraw)
        {
          form_center(tree, &xd, &yd, &wd, &hd);
          objc_draw(tree, ESTMMENU, MAX_DEPTH, xd, yd, wd, hd);
        }
}

        VOID
send_save(slot)
        WORD slot;
{
        LONG            tree;
        WORD            i;

        /*** Routine to save the changes made to the specified slot *****/

        tree = G.a_trees[ADSENDED];

        /* Find the ANODE selected and store that in the list           */
        if ( sanode == -1)
        {
          /* No anode selected - show alert and return                  */
          rsrc_gaddr(R_STRING, STNOSLCT, &G.a_alert);
          form_alert(1, G.a_alert);
          return;
        }

        /* Blank any stuff in the buffer already                        */
        for (i=0; i<13; i++)
          sgl_tmp1[i] = 0;

        /* Copy the correct app name into the buffer                    */
        LSTCPY(sad_tmp1, ADDR(sg_fslist[sanode]));

        /* Copy that into the slot's application name field...          */
        for (i=0; i<12; i++)
          sendto_list[slot].appl[i] = sgl_tmp1[i];
        sendto_list[slot].appl[12] = 0; /* ...and terminate it          */

        /* Set the entry to be an application                           */
        sendto_list[slot].type = ST_APPL;

        /* Set the entry's name                                         */
        inf_sget(tree, ESTMNAME, &sendto_list[slot].name[0]);

        /* Update the display                                           */
        send_mupd( TRUE );
}

        VOID
send_clear(slot)
        WORD slot;
{
        BYTE i;

        /*** Routine to clear the specified slot number. ****************/

        sendto_list[slot].type = ST_EMPTY;
        for (i=0; i<20; i++)
          sendto_list[slot].name[i] = 0;
        for (i=0; i<13; i++)
          sendto_list[slot].appl[i] = 0;
        sapp = -1;
        sanode = -1;

        send_cchk();
        send_mupd( TRUE );
}

/************************************************************************/
/*** External interface routines - don't call anything above here from  */
/***                               outside of this module please.       */
/************************************************************************/

        VOID
send_upd(VOID)
{
        LONG    tree;
        BYTE    ii, tempstr[24];
        BYTE    FAR *temp;

        /*** Routine to update the menu *********************************/

        tree = G.a_trees[ADMENU];
        for(ii=0; ii<8; ii++)
          switch(sendto_list[ii].type)
          {
            case ST_EMPTY:
              menu_text(G.a_trees[ADMENU], STE1ITEM+ii, sad_estsl);
              menu_ienable(tree, STE1ITEM+ii, FALSE);
              break;
            case ST_APPL:
              temp = (FAR) &tempstr[0];
              *temp++ = ' ';
              *temp++ = ' ';
              strcpy(&sendto_list[ii].name[0], temp);
              temp = (FAR) &tempstr[0];
              menu_text(G.a_trees[ADMENU], STE1ITEM+ii, temp);
              menu_ienable(tree, STE1ITEM+ii, TRUE);
              break;
          }
        send_trun();
}

        VOID
send_init(VOID)
{
        BYTE    i;

        /*** Routine to initialise the Send To list ********************/

        for(i=0; i<8; i++)
          sendto_list[i].type = ST_EMPTY;
        rsrc_gaddr(R_STRING, STESTSL, &sad_estsl);
        trun_mode = 0;
        send_upd();
}

        VOID
send_edit(VOID)
{
      WORD            done, touchob;
      LONG            tree;
      WORD            curritem;
      WORD            i, xd, yd, hd, wd, j;
      WORD            acurrtop, move;
      GRECT           pt;
      WORD            mx, my, kret, bret;
      STNODE          oldlist[8];
      WORD            oldtrun;

      /*** Routine to do the 'Edit Send To menu...' dialog box. *********/

      for(i=0; i<8; i++)
      {
        oldtrun = trun_mode;
        oldlist[i].type = sendto_list[i].type;
        for(j=0; j<20; j++)
          oldlist[i].name[j] = sendto_list[i].name[j];
        for(j=0; j<13; j++)
          oldlist[i].appl[j] = sendto_list[i].appl[j];
      }

      done = FALSE;
      tree = G.a_trees[ADSENDED];          

      acount = send_names(tree);
      acurrtop = 0;

      send_elev(tree, acurrtop, acount);

      send_mupd( FALSE );

      /* Select the first item in the Send To list                      */
      sapp = sanode = -1;
      LWSET(OB_STATE(ESTME1), SELECTED);
      curritem = 0;
      inf_sset(tree, ESTMNAME, &sendto_list[curritem].name[0]);

      if (sendto_list[curritem].type == ST_APPL)
        sanode = send_find(curritem);
      else
        sanode = -1;

      if ( (sanode >= acurrtop) && (sanode < (acurrtop + 8)) )
        sapp = sanode - acurrtop;
      send_cchk();

      if (trun_mode == 0) i = ESTMCNO;
      if (trun_mode == 1) i = ESTMCSOM;
      if (trun_mode == 2) i = ESTMCALL;
      LWSET(OB_STATE(i), LWGET(OB_STATE(i)) | SELECTED);

      show_hide(FMD_START, tree);
      form_center(tree, &xd, &yd, &wd, &hd);

      while( !done )
      {
        touchob = form_do(tree, 0);
        touchob &= 0x7fff;
        move = 0;
        graf_mkstate(&mx, &my, &kret, &bret);
        switch(touchob)       
        {
                case ESTMOK:
                case ESTMCAN:
                  LWSET(OB_STATE(touchob), NORMAL);
                  done = TRUE;
                  break;
                case ESTME1:
                case ESTME2:
                case ESTME3:
                case ESTME4:
                case ESTME5:
                case ESTME6:
                case ESTME7:
                case ESTME8:
                  curritem = touchob - ESTME1;
                  inf_sset(tree, ESTMNAME, &sendto_list[curritem].name[0]);
                  objc_draw(tree, ESTMNAME, MAX_DEPTH, xd, yd, wd, hd);

                  sapp = -1;
                  if (sendto_list[curritem].type == ST_APPL)
                    sanode = send_find(curritem);
                  else
                    sanode = -1;

                  move = -acount;
                  send_cchk();
                  break;
                case ESTMSAVE:
                case ESTMCLR:
                  if (touchob == ESTMSAVE)
                    send_save(curritem);
                  else
                    send_clear(curritem);
                  send_cchk();
                  inf_sset(tree, ESTMNAME, &sendto_list[curritem].name[0]);
                  objc_draw(tree, ESTMNAME, MAX_DEPTH, xd, yd, wd, hd);
                  LWSET(OB_STATE(touchob), NORMAL);
                  objc_draw(tree, touchob, MAX_DEPTH, xd, yd, wd, hd);
                  break;
                case ESTMA1:
                case ESTMA2:
                case ESTMA3:
                case ESTMA4:
                case ESTMA5:
                case ESTMA6:
                case ESTMA7:
                case ESTMA8:
                case ESTMAC1:
                case ESTMAC2:
                case ESTMAC3:
                case ESTMAC4:
                case ESTMAC5:
                case ESTMAC6:
                case ESTMAC7:
                case ESTMAC8:
                  if ((touchob >= ESTMA1) && (touchob <= ESTMA8))
                     sapp = touchob - ESTMA1;
                  else
                     sapp = touchob - ESTMAC1;
                  sanode = sapp + acurrtop;
                  send_cchk();
                  break;
                case ESTMCNO:
                  trun_mode = 0;
                  break;
                case ESTMCSOM:
                  trun_mode = 1;
                  break;
                case ESTMCALL:
                  trun_mode = 2;
                  break;
                case ESTMAUP:
                  move = -1;
                  break;
                case ESTMADN:
                  move = 1;
                  break;
                case ESTMABAR:
                  ob_actxywh(tree, ESTMASLD, &pt);
                  if ( inside(mx, my, &pt) )
                    goto dofelev;
                  move = (my <= pt.g_y) ? -1 : 1;
                  break;
                case ESTMASLD:
  dofelev:        wind_update(3);
                  move = graf_slidebox(tree, ESTMABAR, ESTMASLD, TRUE);
                  wind_update(2);
                  move = mul_div(move, acount-1, 1000) - acurrtop;
                  break;
        }
        if (move)
        {
            sapp = -1;
            acurrtop = send_scroll(tree, acurrtop, acount, move);
            if ( (sanode >= acurrtop) && (sanode < (acurrtop + 8)) )
              sapp = sanode - acurrtop;
            send_cchk();
        }
      }

      if (touchob == ESTMCAN)
        for(i=0; i<8; i++)
        {
          sendto_list[i].type = oldlist[i].type;
          for(j=0; j<20; j++)
            sendto_list[i].name[j] = oldlist[i].name[j];
          for(j=0; j<13; j++)
            sendto_list[i].appl[j] = oldlist[i].appl[j];
          trun_mode = oldtrun;
        }


      show_hide(FMD_FINISH, tree);

      /* Clean up the dialog for next use                               */
      for (i=0; i<8; i++)
      {
        LWSET(OB_STATE(ESTME1+i), NORMAL);
        LWSET(OB_STATE(ESTMA1+i), NORMAL);
        LWSET(OB_STATE(ESTMAC1+i), NORMAL);
      }
      LWSET(OB_STATE(ESTMCNO), LWGET(OB_STATE(ESTMCNO)) & !SELECTED);
      LWSET(OB_STATE(ESTMCSOM), LWGET(OB_STATE(ESTMCSOM)) & !SELECTED);
      LWSET(OB_STATE(ESTMCALL), LWGET(OB_STATE(ESTMCALL)) & !SELECTED);

      send_upd();
}

        WORD
do_sendmenu( item )                             
        WORD item;
{
        WORD    done;

        /*** Handles messages involving the Send To menu ****************/

        done = FALSE;

        switch( item )
        {
          case ESTMITEM:        /* Edit Send To menu...                 */
            send_edit();
            break;
          case STE1ITEM:        /* Send To options 1...                 */
          case STE2ITEM:
          case STE3ITEM:
          case STE4ITEM:
          case STE5ITEM:
          case STE6ITEM:
          case STE7ITEM:
          case STE8ITEM:        /* ... through 8.                       */
            done = send_to(item - STE1ITEM);
            break;
        }
        return(done);
}

        WORD
send_with( curr )
        WORD    curr;
{
        /*** Routine to do the 'Open With...' call **********************/

        if (curr)
          not_implemented();

        return(FALSE);
}

/************************************************************************/
/*** DESKTOP.INF/DESKAPP.C interface routines                           */
/************************************************************************/

/*** DESKTOP.INF Code ***************************************************/
/* BALJ 19991221 - The two routines below are called from DESKAPP.C     */
/* when processing DESKTOP.INF.  When writing, the send_write is called */
/* _once_ to write out the whole lot.  When reading, each line with an  */
/* 'e' (extension) as the category is passed through to every known     */
/* $EXTENSION-MODULE_read function - if the line is for a different     */
/* extension module, leave pcurr where it was on entry and return it.   */
/*** DESKTOP.INF Code ***************************************************/

        BYTE
*send_write( pcurr )
        BYTE    *pcurr;
{
        WORD    slot, i;

        /*** Routine to write the Send To list and options out **********/

        *pcurr++ = '#';
        *pcurr++ = 'e';         /* 'e' - new extensions use this code   */
        *pcurr++ = 'S';         /* 'ST' - Send To                       */
        *pcurr++ = 'T';
        *pcurr++ = 'S';         /* 'S' - Settings.  Only 1 used now     */
        *pcurr++ = '0' + trun_mode;
        *pcurr++ = 0x0d;
        *pcurr++ = 0x0a;

        for (slot=0; slot<8; slot++)
        {
#ifdef NOEMPTYINFS
         if (sendto_list[slot].type != ST_EMPTY)
         {
#endif
          *pcurr++ = '#';
          *pcurr++ = 'e';         /* 'e' - new extensions use this code   */
          *pcurr++ = 'S';         /* 'ST' - Send To                       */
          *pcurr++ = 'T';
#ifdef NOEMPTYINFS
         }
#endif
          switch (sendto_list[slot].type)
          {
#ifdef NOEMPTYINFS
            /* Don't output empty lines to the DESKTOP.INF              */
#else
            case ST_EMPTY:
              *pcurr++ = 'E';
              break;
#endif
            case ST_APPL:
              *pcurr++ = 'A';
              for(i=0; i<20; i++)
                *pcurr++ = sendto_list[slot].name[i];
              *pcurr++ = '@';
              for(i=0; i<12; i++)
                *pcurr++ = sendto_list[slot].appl[i];
              *pcurr++ = '@';
              break;
          }
#ifdef NOEMPTYINFS
         if (sendto_list[slot].type != ST_EMPTY)
         {
#endif
          *pcurr++ = 0x0d;
          *pcurr++ = 0x0a;
#ifdef NOEMPTYINFS
         }
#endif
        }
        return(pcurr);
}

        BYTE
*send_read( pcurr )
        BYTE    *pcurr;
{
        WORD    i;

        /*** Routine to read the list and options back in ***************/

        if (slinesread >= 8)     /* Too many lines read.         */
        {
          my_beep();            /* Can't do this...             */
          return(pcurr);
        }

        switch (*pcurr++)
        {
          case 'E':
            sendto_list[slinesread++].type = ST_EMPTY;
            break;
          case 'S':     /* Settings - only one used currently   */
            trun_mode = *pcurr - '0';
            break;
          case 'A':     /* This is an application line for us   */
            for(i=0; i<20; i++)
              sendto_list[slinesread].name[i] = *pcurr++;
            if (*pcurr++ != '@')   /* Panic - fields mismatch   */
              my_beep();           /* Beep, but continue on     */
            for(i=0; i<12; i++)
              sendto_list[slinesread].appl[i] = *pcurr++;
            if (*pcurr++ != '@')   /* Panic - fields mismatch   */
              my_beep();           /* Beep, but continue on     */
            sendto_list[slinesread++].type = ST_APPL;
            break;

        }
        return(pcurr);
}
