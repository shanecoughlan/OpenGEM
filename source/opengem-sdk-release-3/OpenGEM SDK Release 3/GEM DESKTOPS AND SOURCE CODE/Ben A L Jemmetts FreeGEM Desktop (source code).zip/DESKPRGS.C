/***************************************************************************/
/* DESKPRGS.C                                                              */
/* |- FreeGEM Desktop Program Group handling code                          */
/* |- Last modified 19991023 by Ben A L Jemmett                            */
/* |                                                                       */
/* |- (C)opyright Ben A L Jemmett 1999.  This code is covered by the GNU   */
/* |     General Public License.  See LICENSE.TXT for more information.    */
/* |                                                                       */
/* +- Revision History:                                                    */
/*    19991023: Created this file.                                         */
/***************************************************************************/

#include <deskprgs.h>
