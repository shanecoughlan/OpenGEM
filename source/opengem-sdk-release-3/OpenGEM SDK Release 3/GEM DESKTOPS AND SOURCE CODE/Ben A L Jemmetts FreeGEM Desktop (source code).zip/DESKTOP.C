/*      DESKTOP.C       05/04/84 - 09/05/85     Lee Lorenzen            */
/*	for 3.0		3/12/86  - 1/29/87	MDF			*/
/*      FreeGEM 3.15    19990503                Ben A L Jemmett         */
/*      colour schemes  19990515 - 19990520     Ben A L Jemmett         */
/*      merge Ken's in  19990715                BALJ, ken               */
/*      some cosmetics  19990713 - 19990715     Ben A L Jemmett         */
/*      add Window menu 19990715                Ben A L Jemmett         */
/*      add 'Fit to...' 19990716                Ben A L Jemmett         */
/*      Compat. cnx_    19991220                Ben A L Jemmett         */
/*      Send To menu    19991220                Ben A L Jemmett         */
/*      Cmd. Prmpt. Dir 19991222                Ben A L Jemmett         */
/*      Merge XM RSCs   19991223                Ben A L Jemmett         */

/*
*       Copyright 1999, Caldera Thin Clients, Inc.                      
*       This software is licenced under the GNU Public License.         
*       Please see LICENSE.TXT for further information.                 
*                                                                       
*                  Historical Copyright                                 
*	-------------------------------------------------------------
*	GEM Desktop					  Version 2.3
*	Serial No.  XXXX-0000-654321		  All Rights Reserved
*	Copyright (C) 1987			Digital Research Inc.
*	-------------------------------------------------------------
*/

#include <portab.h>
#include <machine.h>
#include <obdefs.h>
#include <taddr.h>
#include <dos.h>
#include <gembind.h>
#include <desktop.h>
#include <deskapp.h>
#include <deskfpd.h>
#include <deskwin.h>
#include <infodef.h>
#include <deskbind.h>

#define abs(x) ( (x) < 0 ? -(x) : (x) )

/* BugFix	*/
					/* keyboard shortcuts & others	*/
#define ESCAPE 0x011B			/* resort directory in window	*/
#define ALTA 0x1E00			/* Configure App		*/
#define ALTC 0x2E00			/* Enter DOS commands		*/
#define ALTD 0x2000			/* Delete			*/
#define ALTF 0x2100                     /* Fit to Screen/Window         */
#define ALTI 0x1700			/* Info/Rename			*/
#define ALTN 0x3100			/* Sort by Name			*/
#define ALTP 0x1900			/* Sort by Type			*/
#define ALTS 0x1F00			/* Show as Text/Icons		*/
#define ALTT 0x1400			/* Sort by Date			*/
#define ALTV 0x2F00			/* Save Desktop			*/
#define ALTW 0x1100                     /* New Window                   */
#define ALTZ 0x2C00			/* Sort by Size			*/
#define CNTLD 0x2004                    /* Disk Drives                  */
#define CNTLU 0x1615			/* To Output			*/
#define CNTLQ 0x1011			/* Exit To Dos			*/

#define BEG_UPDATE 1
#define END_UPDATE 0

#define NUM_BB  16                      /* Number of BitBlcks           */

/* */
#define SPACE 0x20

EXTERN WORD	wildcmp();
						/* in GSXIF.A86		*/
EXTERN VOID     gsx_start();
						/* in DESKPRO.C		*/
EXTERN WORD	pro_exit();
						/* in DESKFPD.C		*/
EXTERN WORD	fpd_start();
EXTERN FNODE	*fpd_ofind();
						/* in DESKWIN.C		*/
EXTERN WORD	win_start();
EXTERN WORD	win_isel();
EXTERN WNODE	*win_alloc();
EXTERN WNODE	*win_find();

						/* in DESKAPP.C		*/
EXTERN BYTE	app_blddesk();
EXTERN WORD	app_start();
EXTERN VOID	app_tran();
						/* in DESKACT.C		*/
EXTERN WORD	act_bsclick();
EXTERN WORD	act_bdown();
						/* in DESKRSRC.C	*/
EXTERN BYTE	*ini_str();

EXTERN WORD	graf_mouse();
EXTERN VOID	win_srtall();
EXTERN VOID	win_bdall();
EXTERN VOID	win_shwall();
EXTERN WORD	menu_ienable();
EXTERN WORD	menu_click();
EXTERN WORD	is_installed();
EXTERN VOID	show_hide();
EXTERN WORD	form_do();
EXTERN WORD     sound(); 
EXTERN WORD	do_open();
EXTERN VOID	do_info();
EXTERN VOID	fun_del();
EXTERN VOID	do_format();
EXTERN WORD	pro_run();
EXTERN WORD	menu_text();
EXTERN WORD	menu_icheck();
EXTERN VOID	win_view();
EXTERN WORD	ins_disk();
EXTERN VOID	do_chkall();
EXTERN WORD	ins_app();
EXTERN WORD	inf_pref();
EXTERN VOID	app_save();
EXTERN WORD	pro_cmd();
EXTERN WORD	wind_find();
EXTERN VOID	desk_clear();
EXTERN VOID	desk_verify();
EXTERN WORD	wind_get();
EXTERN WORD	graf_mkstate();
EXTERN VOID	fun_drag();
EXTERN WORD	menu_tnormal();
EXTERN VOID	do_wredraw();
EXTERN WORD	wind_set();
EXTERN VOID	win_top();
EXTERN VOID	do_wfull();
EXTERN VOID	win_arrow();
EXTERN VOID	win_slide();
EXTERN VOID	win_hslide();				/* 5/30/99 -ken */
EXTERN VOID	do_xyfix();
EXTERN WORD	evnt_dclick();
EXTERN WORD	evnt_timer();
EXTERN VOID	fpd_parse();
EXTERN VOID	pro_chdir();
EXTERN VOID	do_diropen();
EXTERN VOID	do_fopen();
EXTERN WORD     appl_init();
EXTERN WORD	graf_handle();
EXTERN VOID	gsx_vopen();
EXTERN WORD	min();
EXTERN WORD	rsrc_load();
EXTERN WORD	rsrc_gaddr();
EXTERN WORD	fun_alert();
EXTERN WORD	menu_bar();
EXTERN VOID	rc_copy();
EXTERN WORD	evnt_multi();
EXTERN WORD	wind_update();
EXTERN VOID	gsx_vclose();
EXTERN WORD	appl_exit();
EXTERN WORD	strlen();
EXTERN WORD	shel_get();
EXTERN VOID     do_movsiz();    /* in DESKWIN.C */
EXTERN VOID     fs_sset();      /* in OPTIMIZE.C */
EXTERN WORD     form_alert();   /* in GEMBIND.C */
/* EXTERN WORD     do_dopen(); */ /* unused - BALJ, 19991223 */
EXTERN WORD     ins_shortcut(); /* in DESKINS.C - BALJ 19990821 */
EXTERN VOID     send_upd();     /* BALJ 19991223 */
EXTERN WORD     send_with();
EXTERN VOID     win_free();
EXTERN WORD     do_sendmenu();
EXTERN VOID     app_detect();
EXTERN VOID     draw_fld();


EXTERN WORD	DOS_ERR;
EXTERN WORD	gl_hchar;
EXTERN WORD	gl_wchar;

EXTERN WORD	gl_wbox;
EXTERN WORD	gl_hbox;

EXTERN WORD	gl_handle;

GLOBAL BYTE	gl_amstr[4];
GLOBAL BYTE	gl_pmstr[4];

#if MULTIAPP

EXTERN ANODE	*app_afind();
EXTERN WORD	gl_height;
EXTERN VOID	iac_init();
EXTERN VOID	ins_acc();
EXTERN VOID	proc_info();
EXTERN WORD	appl_find();
EXTERN WORD	proc_shrink();
EXTERN WORD	proc_switch();
EXTERN WORD	shel_find();
EXTERN VOID	vrn_trnfm();

EXTERN LONG	pr_beggem;
EXTERN LONG	pr_begacc;
EXTERN LONG	pr_begdsk;
EXTERN LONG	pr_topdsk;
EXTERN LONG	pr_topmem;
EXTERN LONG	pr_ssize;
EXTERN LONG	pr_itbl;
EXTERN WORD	pr_kbytes;
EXTERN WORD	gl_fmemflg;

GLOBAL BYTE	gl_bootdr;
GLOBAL WORD	gl_untop;


typedef struct mfdb 
{
    LONG	mp;
    WORD	fwp;
    WORD	fh; 
    WORD	fww; 
    WORD	ff;
    WORD	np;
    WORD	r1; 
    WORD	r2;
    WORD	r3;
} MFDB;
#endif

EXTERN GLOBES	G;

EXTERN BYTE     build[9];
EXTERN WORD     do_colours();

/* forward declaration	*/
VOID		cnx_put();
VOID            cnx_get();

/* BugFix	*/
GLOBAL WORD	ig_close;

GLOBAL WORD	gl_apid;

GLOBAL BYTE     ILL_ITEM[] = {L2ITEM,L3ITEM,L4ITEM,L5ITEM,L6ITEM,L7ITEM,0};
GLOBAL BYTE	ILL_FILE[] = {FORMITEM,IDSKITEM,0};
GLOBAL BYTE	ILL_DOCU[] = {FORMITEM,IDSKITEM,IAPPITEM,0};
GLOBAL BYTE     ILL_FOLD[] = {OUTPITEM,FORMITEM,IDSKITEM,IAPPITEM,WITHITEM,0};
GLOBAL BYTE     ILL_FDSK[] = {OUTPITEM,IAPPITEM,WITHITEM,0};
GLOBAL BYTE     ILL_HDSK[] = {FORMITEM,OUTPITEM,IAPPITEM,WITHITEM,0};
GLOBAL BYTE     ILL_NOSEL[] = {OPENITEM,SHOWITEM,FORMITEM,DELTITEM,WITHITEM,
				IDSKITEM,IAPPITEM,0};
GLOBAL BYTE     ILL_YSEL[] = {OPENITEM,IDSKITEM,FORMITEM,SHOWITEM,0};
GLOBAL BYTE     ILL_SHRT[] = {FORMITEM,OUTPITEM,IDSKITEM,IAPPITEM,WITHITEM,0};
GLOBAL BYTE     ILL_TRSH[] = {OPENITEM,FORMITEM,DELTITEM,OUTPITEM,IDSKITEM,WITHITEM,
                                IAPPITEM,0};

GLOBAL WORD	freq[]=
{
	262, 349, 329, 293, 349, 392, 440, 392, 349, 329, 262, 293,
	349, 262, 262, 293, 330, 349, 465, 440, 392, 349, 698
};

GLOBAL WORD	dura[]=
{
	4, 12, 4, 12, 4, 6, 2, 4, 4, 12, 4, 4, 
	4, 4, 4, 4, 4, 4, 4, 12, 4, 8, 4
};

GLOBAL WORD	gl_swtblks[3] =
{
	160,
	160,
	160
};

GLOBAL LONG	ad_ptext;
GLOBAL LONG	ad_picon;
GLOBAL LONG     ad_pscrn;
GLOBAL LONG     ad_pwin;

GLOBAL GRECT	gl_savewin[NUM_WNODES];	/* preserve window x,y,w,h	*/
GLOBAL GRECT	gl_normwin;		/* normal (small) window size	*/
GLOBAL WORD	gl_open1st;		/* index of window to open 1st	*/
GLOBAL BYTE	gl_defdrv;		/* letter of lowest drive	*/
GLOBAL WORD	can_iapp;		/* TRUE if INSAPP enabled	*/
GLOBAL WORD	can_show;		/* TRUE if SHOWITEM enabled	*/
GLOBAL WORD	can_del;		/* TRUE if DELITEM enabled	*/
GLOBAL WORD	can_output;		/* TRUE if OUTPITEM endabled	*/
GLOBAL WORD	gl_whsiztop;		/* wh of window fulled		*/
GLOBAL WORD	gl_idsiztop;		/* id of window fulled		*/

EXTERN BYTE	gl_afile[];

GLOBAL BYTE     docopyrt;               /* moved from gemain, 19990830  */
GLOBAL X_BUF_V1        aes;
GLOBAL WORD     on_newgem;

        VOID
not_implemented(VOID)
{
        WORD    *foo;

        foo = &build[0];               
        if ( fun_alert(1, STNOIMPL, &foo) == 2 )
          do_deskmenu(ABOUITEM);
}

	VOID
copy_icon(dst_tree, tree, dst_icon, icon)
	LONG		dst_tree, tree;
	WORD		dst_icon, icon;
{
	LLSET(obaddr(dst_tree, dst_icon, 12), LLGET(OB_SPEC(icon)));
}

	VOID
fix_wins()
{
/* this routine is supposed to keep track of the windows between	*/
/* runs of the Desktop. it assumes pws has already been set up;		*/
/* gl_savewin is set up by app_start.					*/
	WSAVE		*pws0, *pws1;

	gl_open1st = 0;				/* default case		*/
	pws0 = &G.g_cnxsave.win_save[0];
	pws1 = &G.g_cnxsave.win_save[1];
						/* upper window is full	*/
	if ( (gl_savewin[0].g_y != gl_savewin[1].g_y) &&
	     (gl_savewin[0].g_h != gl_savewin[1].g_h) )
	{
					/* which window is upper/lower?	*/
	  if (gl_savewin[0].g_h > gl_savewin[1].g_h)
	  {				/* [0] is (full) upper window	*/
	    gl_open1st = 1;
	    gl_idsiztop = 0;
            pws0->y_save = G.g_yfull;
	    pws0->h_save = G.g_hfull;
	    pws1->y_save = gl_normwin.g_y + gl_normwin.g_h + (gl_hbox / 2);
            pws1->h_save = gl_normwin.g_h; 
	  }
	  else
	  {				/* [1] is (full) upper window	*/
	    gl_open1st = 0;
	    gl_idsiztop = 1;
            pws1->y_save = G.g_yfull;
	    pws1->h_save = G.g_hfull;
	    pws0->y_save = gl_normwin.g_y + gl_normwin.g_h + (gl_hbox / 2);
            pws0->h_save = gl_normwin.g_h;  
	  } /* else */
	} /* if */
	  				/* case 3: lower window is full	*/
	else if ( (gl_savewin[0].g_y == gl_savewin[1].g_y) &&
		  (gl_savewin[0].g_h != gl_savewin[1].g_h) )
	{
					/* which window is upper/lower?	*/
	  if (gl_savewin[0].g_h > gl_savewin[1].g_h)
	  {				/* [0] is (full) lower window	*/
	    gl_open1st = 1;
	    gl_idsiztop = 0;
            pws0->y_save = G.g_yfull;
	    pws0->h_save = G.g_hfull;
	    pws1->y_save = gl_normwin.g_y;
            pws1->h_save = gl_normwin.g_h; 
	  }
	  else
	  {				/* [1] is (full) lower window	*/
	    gl_open1st = 0;
	    gl_idsiztop = 1;
            pws1->y_save = G.g_yfull;
	    pws1->h_save = G.g_hfull;
	    pws0->y_save = gl_normwin.g_y;
            pws0->h_save = gl_normwin.g_h; 
	  } /* else */
	} /* if */
} /* fix_wins */

/*
*	Turn on the hour glass to signify a wait and turn it off when were
*	done.
*/
	VOID
desk_wait(turnon)
	WORD		turnon;
{
	graf_mouse( (turnon) ? HGLASS : ARROW, 0x0L);
}


/*
*	Routine to update all of the desktop windows
*/
	VOID
desk_all(sort)
	WORD		sort;
{
	desk_wait(TRUE);
	if (sort)
	  win_srtall();
	win_bdall();
	win_shwall();
	desk_wait(FALSE);
}

/*
*	Given an icon index, go find the ANODE which it represents
*/
	ANODE
*i_find(wh, item, ppf, pisapp)
	WORD		wh;
	WORD		item;
	FNODE		**ppf;
	WORD		*pisapp;
{
	ANODE 	*pa;
	BYTE 	*pname;
	WNODE	*pw;
	FNODE	*pf;

	pa = (ANODE *) NULL;
	pf = (FNODE *) NULL;

	pw = win_find(wh);
	pf = fpd_ofind(pw->w_path->p_flist, item);
	if (pf)
 	{
	  pname = &pf->f_name[0];
	  pa = pf->f_pa;
	  if ( (pf->f_attr & F_DESKTOP) ||
	       (pf->f_attr & F_SUBDIR) )
	    *pisapp = FALSE;
	  else 
	    *pisapp = wildcmp(pa->a_pappl, pname);
	}
	*ppf = pf;
	return (pa);
}

/*
*	Enable/Disable the menu items in dlist
*/
	VOID
men_list(mlist, dlist, enable)
	LONG		mlist;
	BYTE		*dlist;
	WORD		enable;
{
	while (*dlist)
	  menu_ienable(mlist, *dlist++, enable);
}

/*
* 	Based on current selected icons, figure out which
*	menu items should be selected (deselected)
*/
	VOID
men_update(tree)
	LONG		tree;
{
	WORD		item, nsel, *pjunk, isapp;
	BYTE		*pvalue;
	ANODE		*appl;
						/* enable all items	*/
	for (item = OPENITEM; item <= PREFITEM; item++)
	  menu_ienable(tree, item, TRUE);
	can_iapp = TRUE;
	can_show = TRUE;
	can_del = TRUE;
	can_output = TRUE;
	  					/* disable some items	*/
	men_list(tree, ILL_ITEM, FALSE);

	nsel = 0;
	for (item = 0; (item = win_isel(G.g_screen, G.g_croot, item)) != 0;
	     nsel++)
	{
	  appl = i_find(G.g_cwin, item, &pjunk, &isapp);
	  switch (appl->a_type)
	  {
	    case AT_ISFILE:
		if ( (isapp) || is_installed(appl) )
		  pvalue = ILL_FILE;
		else
		{
		  pvalue = ILL_DOCU;
		  can_iapp = FALSE;
		} 
		break;
	    case AT_ISFOLD:
		pvalue = ILL_FOLD;
		can_iapp = FALSE;
		can_output = FALSE;
		break;
	    case AT_ISDISK:
                /*  BALJ 19990721 - Extended disk icons         */
                if (appl->a_aicon == IG_FLOPPY ||
                    appl->a_aicon == IG_5QRTR )
                      pvalue = ILL_FDSK;
                else
                  pvalue = ILL_HDSK;

/*                pvalue = (appl->a_aicon == IG_FLOPPY) ? ILL_FDSK : ILL_HDSK;*/
		can_iapp = FALSE;
		can_output = FALSE;
		break;
           case AT_ISSHRT:
                /* BALJ 19990721 - Shortcut support             */
                pvalue = ILL_SHRT;
                can_iapp = FALSE;
                can_output = FALSE;
                break;
           case AT_ISTRSH:
                /* BALJ 19990722 - Trashcan support             */
                pvalue = ILL_TRSH;
                can_iapp = FALSE;
                can_output = FALSE;
                break;
	  } /* switch */
          send_upd();   /* BALJ 19991220        */
          men_list(tree, pvalue, FALSE);       /* disable certain items	*/
	} /* for */

	if ( nsel != 1 )
	{
	  if (nsel)
	  {
	    pvalue = ILL_YSEL;
	    can_show = FALSE;
	  }
	  else
	  {
	    pvalue = ILL_NOSEL;
	    can_show = FALSE;
	    can_del = FALSE;
	    can_iapp = FALSE;
	  }
	  men_list(tree, pvalue, FALSE);
	} /* if */
} /* men_update */

	WORD
do_deskmenu(item)
	WORD		item;
{
        WORD            adone, done, touchob, mx, my, foo, bar;
        WORD            i,pane, hide, show,x,y,w,h,key;
        LONG            tree;

        adone = FALSE;
	done = FALSE;
	switch( item )
	{
          case ABOUITEM:                            /* Info box   */

                tree = G.a_trees[ADDINFO];          

		show_hide(FMD_START, tree);
		while( !done )
		{
	          touchob = form_do(tree, 0);
	          touchob &= 0x7fff;
                  if ( touchob == DEICON )          /* Reimplemented easter egg */
                  {                                 /* BALJ - 19990503          */
                    for(i=0; i<23; i++)
                    sound(TRUE, freq[i], dura[i]);
                  }
                  else if ( touchob == DEAUTHOR )   /* BALJ : If Authors button */
                    {                               /* triggered, set flags.    */
                      adone = TRUE;
                      done = TRUE; 
                    }
                  else
                      done = TRUE;
                }   

                LWSET(OB_STATE(DEAUTHOR), NORMAL);
                LWSET(OB_STATE(DEOK), NORMAL);

		show_hide(FMD_FINISH, tree);
		done = FALSE;

                if ( adone == TRUE )                /* If authors flag set do the */
                {                                   /* AUTHOR tree dialog         */
                  tree = G.a_trees[AUTHOR];         /* Get the right tree         */

                  show = LWGET(OB_FLAGS(DRIPANE));
                  hide = LWGET(OB_FLAGS(CTCPANE));

                  show_hide(FMD_START, tree);       /* Show it and do the loop    */
                  pane = 0;
/*                  evnt_timer(150,0);*/

                  while (!done)
                  {
                    touchob = form_do(tree, 0);
                    touchob &= 0x7fff;

                    if (touchob == AUTHOK) done = TRUE;
                    if (touchob == AUTHLBUT) pane--;
                    if (touchob == AUTHRBUT) pane++;
                    if ((touchob == AUTHLBUT) || (touchob == AUTHRBUT))
                    {
                      if (pane == 3) pane = 0;
                      if (pane == -1) pane = 2;

                      LWSET(OB_FLAGS(DRIPANE), hide);
                      LWSET(OB_FLAGS(GPLPANE), hide);
                      LWSET(OB_FLAGS(CTCPANE), hide);

                      switch (pane)
                      {
                        case 0:
                          LWSET(OB_FLAGS(DRIPANE), show);
                          break;
                        case 1:
                          LWSET(OB_FLAGS(GPLPANE), show);
                          break;
                        case 2:
                          LWSET(OB_FLAGS(CTCPANE), show);
                          break;
                      }
                      objc_offset(tree, CTCPANE, &x, &y);
                      w = LWGET(OB_WIDTH(CTCPANE));
                      h = LWGET(OB_HEIGHT(CTCPANE));
                      objc_draw(tree, ROOT, MAX_DEPTH, x, y, w, h);
                    }
                  }
                  LWSET(OB_STATE(AUTHOK), NORMAL);  /* Reset button state         */
                  show_hide(FMD_FINISH, tree);      /* Remove dialog              */
                  adone = FALSE;                    /* Clear flag                 */

                  LWSET(OB_FLAGS(CTCPANE), hide);
                  LWSET(OB_FLAGS(GPLPANE), hide);
                  LWSET(OB_FLAGS(DRIPANE), show);
                }

                break;

	}
        return(FALSE);
}


	WORD
do_filemenu(item)
	WORD		item;
{
	WORD		done;
	WORD		curr, junk, first;
	WNODE		*pw;
	FNODE		*pf;
	BYTE		*pdst;

#if MULTIAPP
	ANODE		*pa;
#endif
	
	done = FALSE;
	pw = win_find(G.g_cwin);
	curr = win_isel(G.g_screen, G.g_croot, 0);
	switch( item )
	{
	  case OPENITEM:
		if (curr)
		  done = do_open(curr);
		break;
          case WITHITEM:
                if (curr)
                  done = send_with(curr);
                break;
	  case SHOWITEM:
		if (curr)
		  do_info(curr);
		break;
	  case DELTITEM:
		if (curr)
		  fun_del(pw);
		break;
	  case FORMITEM:
		if (curr)
		  do_format(curr);
		break;   
	  case OUTPITEM:

			/* build cmd tail that looks like this:		*/
			/* C:\path\*.*,file.ext,file.ext,file.ext	*/
		G.g_tail[1] = NULL;
		if (pw && curr)
		{
		  pdst = strcpy(&pw->w_path->p_spec[0], &G.g_tail[1]);
		  			/* check for no path defined	*/
		  if (pw->w_path->p_spec[0] == '@')
		    G.g_tail[1] = gl_defdrv;
						/* while there are	*/
						/*   filenames append	*/
						/*   them in		*/
		  first = TRUE;
		  while(curr)
		  {
		    if (first)
		    {
		      while (*pdst != '\\')
		        pdst--;
		      pdst++;
		      *pdst = NULL;
		      first = FALSE;
		    }
		    else
		    {
		      pdst--;
		      *pdst++ = ',';
		    }
		    i_find(G.g_cwin, curr, &pf, &junk);
		    pdst = strcpy(&pf->f_name[0], pdst);
						/* if there is room for	*/
						/*   another filename &;*/
						/*   then go fetch it	*/ 
		    if ( (&G.g_tail[127] - pdst) > 16 )
		      curr = win_isel(G.g_screen, G.g_croot, curr);
		    else
		      curr = 0;
		  } /* while */
		} /* if pw */
		strcpy(ini_str(STGEMOUT), &G.g_cmd[0]);
#if MULTIAPP
		pa = app_afind(FALSE, AT_ISFILE, -1, &G.g_cmd[0], &junk);
		pr_kbytes = (pa ? pa->a_memreq : 256);
		pro_run(TRUE, -1, -1, -1);
#else
		done = pro_run(TRUE, TRUE, -1, -1);
#endif
		break;
	  case QUITITEM:
#if MULTIAPP
		if (fun_alert(1,STEXTDSK,NULLPTR) == 2)		/* CANCEL */
		  break;
		else
#endif            
		pro_exit(G.a_cmd, G.a_tail);
		done = TRUE;
		break;
#if DEBUG
	  case DBUGITEM:
		debug_run();
		break;
#endif
	}
	return(done);
} /* do_filemenu */


	WORD
do_viewmenu(item)
	WORD		item;
{
        WORD            newview, newsort, newwrap;
	LONG		ptext;

	newview = G.g_iview;
	newsort = G.g_isort;
	switch( item )
	{
	  case ICONITEM:
		newview = (G.g_iview == V_ICON) ? V_TEXT : V_ICON;
		break;
	  case NAMEITEM:
		newsort = S_NAME;
		break;
	  case DATEITEM:
		newsort = S_DATE;
		break;
	  case SIZEITEM:
		newsort = S_SIZE;
		break;
	  case TYPEITEM:
		newsort = S_TYPE;
		break;
          case ATSWITEM:
                newwrap = (G.g_fittowin == 1) ? 0 : 1;
                break;
	}
	if ( (newview != G.g_iview) ||
	     (newsort != G.g_isort) )
	{
	  if (newview != G.g_iview)
	  {
	    G.g_iview = newview;
	    ptext = (newview == V_TEXT) ? ad_picon : ad_ptext;
	    menu_text(G.a_trees[ADMENU], ICONITEM, ptext);
            menu_ienable(G.a_trees[ADMENU], ATSWITEM, G.g_iview == V_ICON);
	  }
	  if (newsort != G.g_isort)
	  {
	    menu_icheck(G.a_trees[ADMENU], G.g_csortitem, FALSE);
	    G.g_csortitem = item;
	    menu_icheck(G.a_trees[ADMENU], item, TRUE);
	  }
	  win_view(newview, newsort);
	  return(TRUE);			/* need to rebuild	*/
	}

        /* BALJ 19990716 - Wrapping switch                      */
        if ( newwrap != G.g_fittowin )  /* Fit to... changed    */
        {
          /* Change menu, then set flag and rebuild.            */
          ptext = (newwrap == 1) ? ad_pscrn : ad_pwin;
          menu_text(G.a_trees[ADMENU], ATSWITEM, ptext);
          G.g_fittowin = newwrap;
          return( TRUE );
        }

	return( FALSE );
}



	WORD
do_optnmenu(item)
	WORD		item;
{
	ANODE		*pa;
	WORD		done, rebld, curr, ret;
	FNODE		*pf;
	WORD		isapp;
	BYTE		*pstr;
#if MULTIAPP
	WORD		junk;
#endif
        /* BALJ 19991222 - ChDir to current before shelling             */
        WORD            drv;
	BYTE		path[66], name[9], ext[4];
        WNODE           *pw;

	done = FALSE;
	rebld = FALSE;

	curr = win_isel(G.g_screen, G.g_croot, 0);
	if (curr)
	  pa = i_find(G.g_cwin, curr, &pf, &isapp);

	switch( item )
	{
	  case IDSKITEM:
		if (pa)
		  rebld = ins_disk(pa);
		if (rebld)
		{
                  gl_defdrv = app_blddesk(); 
                  do_chkall(TRUE);           
	        }
		break;
	  case IAPPITEM:
		if (pa)
		{
		  if (isapp)
		    pstr = &pf->f_name[0];
		  else if (is_installed(pa))
		    pstr = pa->a_pappl;
		  rebld = ins_app(pstr, pa);
		  rebld = TRUE;	/* WORKAROUND for bug that shows up with */
				/* remove followed by cancel when icon is */
				/* partially covered by dialog.  Icon not */
				/* properly redrawn as deselected -- mdf   */
		}
		if (rebld)
		  desk_all(FALSE);
		break;
#if MULTIAPP
	  case IACCITEM:
		ins_acc();
		break;
#endif
	  case PREFITEM:
		if (inf_pref())
		  desk_all(FALSE);
		break;
	  case SAVEITEM:
		desk_wait(TRUE);
		cnx_put();
		app_save(TRUE);
		desk_wait(FALSE);
		break;
          case SETTITEM:
                done = settings_app();
                break;
          case ICLRITEM:
                done = do_colours();
                break;
	  case DOSITEM:

#if MULTIAPP
		ret = appl_find(ADDR("COMMAND "));
		if (ret == -1)
		{
		  ret = pro_cmd( "\0", "\0", FALSE);
		  if (ret)
		  {
		    pa = app_afind(FALSE, AT_ISFILE, -1,"COMMAND.COM", &junk);
		    pr_kbytes = (pa ? pa->a_memreq : 128);
		    pro_run(FALSE, -1, -1, -1);
		  }
		}
		else
		{
		  menu_tnormal(G.a_trees[ADMENU], OPTNMENU, TRUE);
		  proc_switch(ret);
		}

#else
		ret = pro_cmd( "\0", "\0", FALSE);

                /* BALJ 19991222 - ChDir to current before shelling     */
                pw = win_find(G.g_cwin);
                if (pw)
                {
                  fpd_parse(&pw->w_path->p_spec[0],&drv,&path[0],&name[0],&ext[0]);
                  pro_chdir(drv, &path[0]);
                }

		if (ret)
		  done = pro_run(FALSE, TRUE, -1, -1);
#endif
		break;
	}
	return(done);
}

	WORD
do_windmenu(item)
	WORD		item;
{
        /* BALJ 19990715 - This routine handles the 'Window' menu       */
        WORD            curr, wnum;
	WORD		drv;
	WNODE		*pw;

        switch(item)
        {
        case NEWWITEM:  /* Open a new window to the disk drives.  BALJ  */

        if (G.g_wcnt == NUM_WNODES)
        {
	  rsrc_gaddr(R_STRING, STNOWIND, &G.a_alert);
	  form_alert(1, G.a_alert);
          return(FALSE);
        }

        /* Attempt to allocate a window                                 */
	pw = win_alloc();
        
        if (pw)         /* Got a window                                 */
	{

          curr = 0;
          drv = '@';    /* Disk drives                                  */
	  pro_chdir(drv, "");
          if (!DOS_ERR) /* CHDIRed OK, open directory view              */
 	    do_diropen(pw, TRUE, curr, drv, "", "*", "*",
			&G.g_screen[pw->w_root].ob_x, TRUE);
	  else
            win_free(pw);       /* Failed the CHDIR, close window       */
	}
        else            /* No free window                               */
	{
	  rsrc_gaddr(R_STRING, STNOWIND, &G.a_alert);
	  form_alert(1, G.a_alert);
	}

        break;

        case CLOSITEM:
          pw = win_find(G.g_cwin);
          if ( pw )
          {
            win_free( pw );
            cnx_put();
            return(FALSE);
          }
          break;
        case DISCITEM:
          /* Take the current window to the disc drives                 */
          pw = win_find(G.g_cwin);
          drv = '@';
          pw->w_cvrow = 0;
          pw->w_cvcol = 0;
          do_fopen(pw, 0, drv, "", "*", "*", FALSE, TRUE);
          break;
        case SHRTITEM:
          pw = win_find(G.g_cwin);
          /* Create a shortcut from the current window.                 */
          if (ins_shortcut(pw))
                  do_chkall(TRUE);
        }

        return(FALSE);
}


	WORD
hndl_button(clicks, mx, my, button, keystate)
	WORD		clicks;
	WORD		mx, my, button, keystate;
{
	WORD		done, junk;
	GRECT		c;
	WORD		wh, dobj, dest_wh;


	done = FALSE;
	wh = wind_find(mx, my);
	if (wh != G.g_cwin)
		desk_clear(G.g_cwin);

/* BUGFIX */					/* if click outside win's*/
/*        if (wh == 0){
		men_update(G.a_trees[ADMENU]);
		wind_update(BEG_UPDATE);
                while(button & 0x0001)
                        graf_mkstate(&junk, &junk, &button, &junk);
		wind_update(END_UPDATE);
        return(done);
        }*/
/* */   /* The above block may be be instructive when drawing on the desk */

	desk_verify(wh, FALSE);
	wind_get(wh, WF_WXYWH, &c.g_x, &c.g_y, &c.g_w, &c.g_h);

        if (button ==2)
        {
                sound(TRUE,440,1);
                return(FALSE);
        }


	if (clicks == 1){
                        act_bsclick(G.g_cwin, G.a_screen, G.g_croot, mx, my,
                                                        keystate, &c, FALSE);
                        graf_mkstate(&junk, &junk, &button, &junk);
        
                        if (button & 0x0001) {
                                dest_wh = act_bdown(G.g_cwin, G.a_screen,
                                                        G.g_croot, &mx, &my,
                                                        keystate, &c, &dobj);
                                if ( (dest_wh != NIL) && (dest_wh != 0) ) {
                                        fun_drag(wh, dest_wh, dobj, mx, my);
                                        desk_clear(wh);
                                        } /* if !NIL */
        
                                } /* if button */
		} /* if clicks */

	else {
		act_bsclick(G.g_cwin, G.a_screen, G.g_croot, mx, my,
						keystate, &c, TRUE);
		done = do_filemenu(OPENITEM);
		} /* else */

	men_update(G.a_trees[ADMENU]);

	return(done);
}

	WORD
hndl_kbd(thechar)
	WORD		thechar;
{
	WORD		done;

	done = FALSE;

	switch(thechar)
	{
	  case ESCAPE:
	  	do_chkall(TRUE);
		break;
	  case ALTA:	/* Options: Install App	*/
	  	if (can_iapp)		/* if it's ok to install app	*/
		{
		  menu_tnormal(G.a_trees[ADMENU], OPTNMENU, FALSE);
	  	  done = hndl_menu(OPTNMENU, IAPPITEM);
		}
		break;
	  case ALTC:	/* Options: Enter DOS commands	*/
		menu_tnormal(G.a_trees[ADMENU], OPTNMENU, FALSE);
	  	done = hndl_menu(OPTNMENU, DOSITEM);
		break;
	  case ALTD:	/* File: Delete		*/
	  	if (can_del)		/* if it's ok to delete		*/
		{
	  	  menu_tnormal(G.a_trees[ADMENU], FILEMENU, FALSE);
	  	  done = hndl_menu(FILEMENU, DELTITEM);
		}
		break;
          case ALTF:    /* View: Fit to Screen/Window   */
                if ( G.g_iview == V_ICON )
                {
                  menu_tnormal(G.a_trees[ADMENU], VIEWMENU, FALSE);
                  done = hndl_menu(VIEWMENU, ATSWITEM);
                } else done = FALSE;
		break;
	  case ALTI:	/* File: Info/Rename	*/
	  	if (can_show)		/* if it's ok to show		*/
		{
	  	  menu_tnormal(G.a_trees[ADMENU], FILEMENU, FALSE);
	  	  done = hndl_menu(FILEMENU, SHOWITEM);
		}
		break;
	  case ALTN:	/* View: Sort by Name	*/
	  	menu_tnormal(G.a_trees[ADMENU], VIEWMENU, FALSE);
	  	done = hndl_menu(VIEWMENU, NAMEITEM);
		break;
	  case ALTP:	/* View: Sort by Type	*/
	  	menu_tnormal(G.a_trees[ADMENU], VIEWMENU, FALSE);
	  	done = hndl_menu(VIEWMENU, TYPEITEM);
		break;
	  case ALTS:	/* View: Show as Text/Icons	*/
	  	menu_tnormal(G.a_trees[ADMENU], VIEWMENU, FALSE);
	  	done = hndl_menu(VIEWMENU, ICONITEM);
		break;
	  case ALTT:	/* View: Sort by Date	*/
	  	menu_tnormal(G.a_trees[ADMENU], VIEWMENU, FALSE);
	  	done = hndl_menu(VIEWMENU, DATEITEM);
		break;
	  case ALTV:	/* Options: Save Desktop	*/
	  	menu_tnormal(G.a_trees[ADMENU], OPTNMENU, FALSE);
	  	done = hndl_menu(OPTNMENU, SAVEITEM);
		break;
          case ALTW:    /* Window: New Window           */
                menu_tnormal(G.a_trees[ADMENU], WINDMENU, FALSE);
                done = hndl_menu(WINDMENU, NEWWITEM);
		break;
	  case ALTZ:	/* View: Sort by Size	*/
	  	menu_tnormal(G.a_trees[ADMENU], VIEWMENU, FALSE);
	  	done = hndl_menu(VIEWMENU, SIZEITEM);
		break;
          case CNTLD:   /* Window: Disk Drives           */
                menu_tnormal(G.a_trees[ADMENU], WINDMENU, FALSE);
                done = hndl_menu(WINDMENU, DISCITEM);
		break;
          case CNTLU:
		if (can_output)
	  	{
		  menu_tnormal(G.a_trees[ADMENU], FILEMENU, FALSE);
	  	  done = hndl_menu(FILEMENU, OUTPITEM);
		}
		break;
	  case CNTLQ:
	  	menu_tnormal(G.a_trees[ADMENU], FILEMENU, FALSE);
	  	done = hndl_menu(FILEMENU, QUITITEM);
		break;
	} /* switch */
	men_update(G.a_trees[ADMENU]);		/* clean up menu info	*/
	return(done);
} /* hndl_kbd */

	WORD
hndl_menu(title, item)
	WORD		title;
	WORD		item;
{
	WORD		done;

	done = FALSE;
	switch( title )
	{
	  case DESKMENU:
		done = do_deskmenu(item);
		break;
	  case FILEMENU:
		done = do_filemenu(item);
		break;
	  case VIEWMENU:
		done = FALSE;
						/* for every window	*/
						/*   go sort again and	*/
						/*   rebuild views	*/
		if (do_viewmenu(item))
		desk_all(TRUE);
		break;
	  case OPTNMENU:
		done = do_optnmenu(item);
		break;
          case WINDMENU:                        /* Window menu - BALJ   */
                if (do_windmenu(item))       /* 19990715             */
                  done = FALSE;
                done = FALSE;
                break;
          case SENDMENU:
                done = do_sendmenu(item);
                break;
	}
	menu_tnormal(G.a_trees[ADMENU], title, TRUE);
	return(done);
}


	VOID
hot_close(wh)
	WORD		wh;
{
/* "close" the path but don't set a new dir. & don't redraw the window	*/
/* until the button is up or there are no more CLOSED messages		*/
	WORD		drv, done, at_drvs, cnt;
	WORD		mx, my, button, kstate;
	BYTE		path[66], name[9], ext[4];
	BYTE		*pend, *pname, *ppath;
	WNODE		*pw;

	pw = win_find(wh);
	at_drvs = FALSE;
	done = FALSE;
	cnt = 0;
/*	wind_update(BEG_UPDATE);*/
	do
	{
	  cnt++;
	  ppath = &pw->w_path->p_spec[0];
	  pname = &pw->w_name[0];
	  fpd_parse(ppath, &drv, &path[0], &name[0], &ext[0]);
	  if (path[0] == NULL)	/* No more path; show disk icons */
	  {
	    strcpy(ini_str(STDSKDRV), pname);
	    ppath[3] = '*';
	    ppath[4] = '.';
	    ppath[5] = '*';
	    ppath[6] = NULL;
	    at_drvs = TRUE;
	  }
	  else
	  {			/* Some path left; scan off last dir.	*/
	    pend = pname;
	    pend += (strlen(pname) - 3);	/* skip trailing '\ '	*/
						/* Remove last name	*/
	    while ( (pend != pname) && (*pend != '\\') )
	      pend--;
	    pend++;			  	/* save trailing '\'	*/
/*	    *pend++ = SPACE;*/
	    *pend = NULL;
	    					/* now fix path		*/
	    pend = ppath;
	    pend += (strlen(ppath) - 5);	/* skip trailing '\*.*'	*/
						/* Remove last name	*/
	    while ( (pend != ppath) && (*pend != '\\') )
	      pend--;
	    pend++;				/* save trailing '\'	*/
	    *pend = NULL;
	    strcat("*.*", ppath);		/* put '*.*' back on	*/
	  } /* else */
	  wind_set(pw->w_id, WF_NAME, ADDR(&pw->w_name[0]), 0, 0);
/*	  wind_update(END_UPDATE);*/
	  graf_mkstate(&mx, &my, &button, &kstate);
	  if (button == 0x0)
	    done = TRUE;
	  else
	  {
	    evnt_timer(750, 0);
						/* grab the screen	*/
/*	    wind_update(BEG_UPDATE);*/
	    graf_mkstate(&mx, &my, &button, &kstate);
	    if (button == 0x0)
	      done = TRUE;
	  } /* else */
	} while ( !done );
/*	wind_update(END_UPDATE);*/
	if (cnt > 1)
	  ig_close = TRUE;
/*	desk_verify(G.g_rmsg[3], FALSE);*/
	fpd_parse(ppath, &drv, &path[0], &name[0], &ext[0]);
	if (at_drvs)
	  drv = '@';
	pw->w_cvrow = 0;			/* reset slider		*/
        pw->w_cvcol = 0;
	do_fopen(pw, 0, drv, path, name, ext, FALSE, TRUE);
	cnx_put();
} /* hot_close */

	WORD
hndl_msg()
{
	WORD		done;
	WNODE		*pw;
	WORD		change, menu;

	done = change = menu = FALSE;
	if ( G.g_rmsg[0] == WM_CLOSED && ig_close )
	{
	  ig_close = FALSE;
	  return(done);
	}

        switch( G.g_rmsg[0] ){
		case WM_TOPPED:
                case WM_MOVED:  /* BALJ 20000311 - I don't know who     */
                case WM_SIZED:  /* removed these earlier, but I put 'em */
                case WM_CLOSED: /* back because some stuff broke.       */
		case WM_FULLED:
		case WM_ARROWED:
		case WM_VSLID:
                case WM_HSLID:
			desk_clear(G.g_cwin);
			break;
                        }

	switch( G.g_rmsg[0] ){
		case MN_SELECTED:
			desk_verify(G.g_wlastsel, FALSE);
			done = hndl_menu(G.g_rmsg[3], G.g_rmsg[4]);
			break;
		case WM_REDRAW:
                        menu = TRUE;
#if MULTIAPP
		if (gl_untop){
			gl_untop = FALSE;
			do_chkall(FALSE);
			men_update(G.a_trees[ADMENU]); /*disable some items*/
			}
#endif
                if (G.g_rmsg[3]){
			do_wredraw(G.g_rmsg[3], G.g_rmsg[4], G.g_rmsg[5],
						G.g_rmsg[6], G.g_rmsg[7]);
                        }

			break;

		case WM_TOPPED:
			wind_set(G.g_rmsg[3], WF_TOP, 0, 0, 0, 0);
			pw = win_find(G.g_rmsg[3]);
			if (pw)	{
				win_top(pw);
				desk_verify(pw->w_id, FALSE);
				}
			change = TRUE;
			break;

#if MULTIAPP
		case WM_ONTOP:
			gl_untop = TRUE;
			break;
		case PR_FINISH:
			gl_fmemflg &= (0xff ^ (1 << G.g_rmsg[3]));
			break;
#endif
		case WM_CLOSED:
			hot_close(G.g_rmsg[3]);
			change = TRUE;
			break;
		case WM_FULLED:
			pw = win_find(G.g_rmsg[3]);
			if (pw){
				win_top(pw);
				do_wfull(G.g_rmsg[3]);
				desk_verify(G.g_rmsg[3], TRUE);
				}
			change = TRUE;
			break;
		case WM_ARROWED:
			win_arrow(G.g_rmsg[3], G.g_rmsg[4]);
			change = TRUE;
			break;
		case WM_VSLID:
			win_slide(G.g_rmsg[3], G.g_rmsg[4]);
			change = TRUE;
			break;
		case WM_HSLID:
			win_hslide(G.g_rmsg[3], G.g_rmsg[4]);
			change = TRUE;
			break;
		case WM_MOVED:
		case WM_SIZED:
			pw = win_find(G.g_rmsg[3]);
                        if(pw){
                          do_movsiz(pw, G.g_rmsg[4], G.g_rmsg[5],
                                        G.g_rmsg[6], G.g_rmsg[7]);
                          }
			change = TRUE;
			break;
			}
	if (change)
		cnx_put();
        G.g_rmsg[0] = 0;
        if (!menu)
                men_update(G.a_trees[ADMENU]);

	return(done);

} /* hndl_msg */

	VOID
cnx_put()
{
	WORD		iwin, topped;
	WSAVE		*pws;
	WNODE		*pw;

	G.g_cnxsave.vitem_save = (G.g_iview == V_ICON) ? 0 : 1;
	G.g_cnxsave.sitem_save = G.g_csortitem - NAMEITEM;
	G.g_cnxsave.ccopy_save = G.g_ccopypref;
	G.g_cnxsave.cdele_save = G.g_cdelepref;
	G.g_cnxsave.covwr_save = G.g_covwrpref;
	G.g_cnxsave.cdclk_save = G.g_cdclkpref;
	G.g_cnxsave.cmclk_save = G.g_cmclkpref;
	G.g_cnxsave.ctmfm_save = G.g_ctimeform;
	G.g_cnxsave.cdtfm_save = G.g_cdateform;
        G.g_cnxsave.casoe_save = G.g_saveonexit;                /* BALJ - SOE */
        G.g_cnxsave.catsw_save = G.g_fittowin;                  /* BALJ - wrap */
        G.g_cnxsave.cdetd_save = G.g_detdrives;                 /* BALJ - compatability */
        G.g_cnxsave.cdetn_save = G.g_probedrives;

        G.g_cnxsave.cuoic_save = G.g_useorigcol;
        G.g_cnxsave.cfwht_save = G.g_trashinwin;

        for (iwin = 0; iwin < G.g_wcnt; iwin++){
		pw = win_find(G.g_wlist[iwin].w_id);
		pws = &G.g_cnxsave.win_save[iwin];
		wind_get(pw->w_id, WF_TOP, &topped, 0, 0, 0);

		if(gl_whsiztop != NIL)
		wind_get(pw->w_id, WF_PXYWH, &pws->x_save, &pws->y_save,
					     &pws->w_save, &pws->h_save);
		else
		wind_get(pw->w_id, WF_CXYWH, &pws->x_save, &pws->y_save,
					     &pws->w_save, &pws->h_save);

		pws->hsl_save = pw->w_cvcol;
		pws->vsl_save = pw->w_cvrow;

		pws->obid_save = 0;			/* default = 0 */

		if(pw->w_id == topped){
			pws->obid_save = 1;	     	/* was topped */

			if(gl_whsiztop != NIL)
				pws->obid_save = 2;	/* was fulled too */

			}/*if*/

		strcpy( pw->w_path->p_spec, &pws->pth_save[0]);
		}
} /* cnx_put */

/************************************************************************/
/* c n x _ o p e n							*/
/************************************************************************/
	VOID
cnx_open(idx)
	WORD		idx;
{
	WSAVE		*pws;
	WNODE		*pw;
	WORD		drv;
	BYTE		pname[9];
	BYTE		pext[4];

	pws = &G.g_cnxsave.win_save[idx];

        pw = win_alloc();
        if (pw){

                if(pws->obid_save > 0)          /* added 7/5/99 -ken  */
                        gl_idsiztop = idx;              /* was topped */
                if(pws->obid_save == 2)
                        gl_whsiztop = 1;                /* was fulled too */

                pws->obid_save = 0;                     /* originally = 0 */
                                                        /* just in case   */

                pw->w_cvcol = pws->hsl_save;
                pw->w_cvrow = pws->vsl_save;
                fpd_parse(&pws->pth_save[0], &drv, &G.g_tmppth[0],
                                                &pname[0], &pext[0]);
                if (pname[0] == NULL)
                                drv = NULL;

             /* do_xyfix(&pws->x_save, &pws->y_save);*/

                pro_chdir(drv, &G.g_tmppth[0]);
                if (DOS_ERR){
                        drv = '@';
                        G.g_tmppth[0] = NULL;
                        pname[0] = pext[0] = '*';
                        pname[1] = pext[1] = NULL;
                        }

        do_diropen(pw, TRUE, pws->obid_save, drv, &G.g_tmppth[0],
                        &pname[0], &pext[0], &pws->x_save, TRUE);

        } /*if(pw)*/
} /*cnx_open */

	VOID
cnx_get()
{
	WORD	iwin;
	WNODE	*pw;				/* added 7/5/99 -ken */

	G.g_iview = (G.g_cnxsave.vitem_save == 0) ? V_TEXT : V_ICON;
	do_viewmenu(ICONITEM);
	do_viewmenu(NAMEITEM + G.g_cnxsave.sitem_save);
	G.g_ccopypref = G.g_cnxsave.ccopy_save;
	G.g_cdelepref = G.g_cnxsave.cdele_save;
	G.g_covwrpref = G.g_cnxsave.covwr_save;
	G.g_cdclkpref = G.g_cnxsave.cdclk_save;
	G.g_cmclkpref = G.g_cnxsave.cmclk_save;
	G.g_ctimeform = G.g_cnxsave.ctmfm_save;
        G.g_cdateform = G.g_cnxsave.cdtfm_save;
        G.g_saveonexit = G.g_cnxsave.casoe_save;                /* BALJ - SOE */
        G.g_useorigcol = G.g_cnxsave.cuoic_save;
        G.g_trashinwin = G.g_cnxsave.cfwht_save;

        G.g_fittowin = (G.g_cnxsave.catsw_save == 0) ? 1 : 0;   /* BALJ - Fit */
        do_viewmenu(ATSWITEM);

        G.g_detdrives = G.g_cnxsave.cdetd_save;                 /* BALJ - compatability */
        G.g_probedrives = G.g_cnxsave.cdetn_save;

	G.g_cdclkpref = evnt_dclick(G.g_cdclkpref, TRUE);
	G.g_cmclkpref = menu_click(G.g_cmclkpref, TRUE);

						/*restore windows as saved*/
						/* changed 7/1/99  -ken   */

        /* BALJ 19990914 - if no windows open, had better open one BUGFIX */
        if ( G.g_cnxsave.wins_open == 0 )
          hndl_menu(WINDMENU, NEWWITEM);

        /* BALJ 19990715 - quick fix to open only saved windows to save   */
        /* resources and to allow Open Window.                            */

        for (iwin = 0; iwin < G.g_cnxsave.wins_open; iwin++)  cnx_open(iwin);

        for (iwin = 0; iwin < NUM_WNODES; iwin++)
          if (G.g_wlist[iwin].w_id > 0)
            wind_set(G.g_wlist[iwin].w_id, WF_TOP, 0, 0, 0, 0);

	if(gl_idsiztop != NIL){
		pw = win_find(G.g_wlist[gl_idsiztop].w_id);
		wind_set(pw->w_id, WF_TOP, 0, 0, 0, 0);
		if(gl_whsiztop != NIL){
			wind_set(pw->w_id, WF_SIZTOP, G.g_xfull, G.g_yfull,
						      G.g_wfull, G.g_hfull );
			win_bdall();
			}
		}

        cnx_put(); 
} /* cnx_get */

/* BALJ 19990830 - Displays the string in the status line of the splashscreen */
        VOID
status( status )
        BYTE FAR        *status;
{
        LONG            text, tree;
        WORD            txtlen;

        tree = G.a_trees[ADDINFO];

        if (docopyrt)
        {
          fs_sset(tree, LOADINFO, status, &text, &txtlen);
          draw_fld(tree, LITBACKG);
          draw_fld(tree, LOADINFO);
        }
}

	WORD
gemain()
{
	WORD		ii, done, flags;
	WORD		ev_which, mx, my, button, kstate, kret, bret;
	WSAVE		*pws;
        LONG            tree, plong;
        WORD            hsave, fsave;
#if MULTIAPP
	WORD		junk1, junk2;
	LONG		templn, templn2;
	LONG		csize;
        BYTE            memszstr[4];
        LONG            memsize;
#endif
        X_BUF_V1        aes;
        LONG            text;
        WORD            txtlen, foo, keys;
        WORD            *bar;
        BYTE            oldcol[]={SETTITEM, 0};

/* initialize libraries	*/
        aes.buf_len = sizeof(aes);              /* AES info buffer      */

        gl_apid = appl_init(&aes);              /* BALJ - add X_BUF_V2  */

						/* get GEM's gsx handle	*/
	gl_handle = graf_handle(&gl_wchar, &gl_hchar, &gl_wbox, &gl_hbox);
						/* open a virtual work-	*/
						/*   station for use by	*/
						/*   the desktop	*/
	gsx_vopen();
						/* init gsx and related	*/
						/*   device dependent	*/
						/*   variables		*/

        gsx_start();

	gl_whsiztop = NIL;
	gl_idsiztop = NIL;

                                                /* set clip to working desk */
	wind_get(0, WF_WXYWH, &G.g_xdesk, &G.g_ydesk, &G.g_wdesk, &G.g_hdesk);
	wind_get(0, WF_WXYWH, &G.g_xfull, &G.g_yfull, &G.g_wfull, &G.g_hfull);


                                                /* calculate full desk  */
	G.g_xfull += min(16, gl_wbox);
	G.g_yfull += gl_hbox;
        do_xyfix(&G.g_xfull, &G.g_yfull); 
	G.g_wfull -= (2 * G.g_xfull);
	G.g_hfull -= (2 * gl_hbox);
					/* set up small window size	*/
	gl_normwin.g_x = G.g_xfull;
	gl_normwin.g_y = G.g_yfull;
	gl_normwin.g_w = G.g_wfull;
	gl_normwin.g_h = (G.g_hfull - (gl_hbox / 2)) / 2;
						/* init long addrs that	*/
						/*   will be used alot	*/
	G.a_cmd = ADDR(&G.g_cmd[0]);
	G.a_tail = ADDR(&G.g_tail[0]);
	G.a_fcb1 = ADDR(&G.g_fcb1[0]);
	G.a_fcb2 = ADDR(&G.g_fcb2[0]);
	G.a_rmsg = ADDR(&G.g_rmsg[0]);
						/* initialize mouse	*/
	wind_update(BEG_UPDATE);
	desk_wait(TRUE);
	wind_update(END_UPDATE);

						/* initialize resources	*/
	rsrc_load( ADDR("DESKTOP.RSC") );
						/* initialize menus and	*/
						/*   dialogs		*/
	for(ii = 0; ii < NUM_ADTREES; ii++)
	  rsrc_gaddr(0, ii, &G.a_trees[ii]);





#if MULTIAPP
	templn = G.a_trees[ADDINFO];
	if (gl_height <= 300)
	{					/* get lo-res images	*/
	  templn2 = G.a_trees[ADLRSINF];	
	  copy_icon(templn, templn2, DEICON, LDEICON);
	  copy_icon(templn, templn2, DENAME1, LDENAME1);
	  copy_icon(templn, templn2, DENAME2, LDENAME2);
	  copy_icon(templn, templn2, DENAME3, LDENAME3);
	  copy_icon(templn, templn2, DENAME4, LDENAME4);
	}
#endif

	for (ii=0; ii<NUM_BB; ii++)		/* initialize bit images */
	  app_tran(ii);

        tree = G.a_trees[ADDINFO];

                                                /* BALJ - AES detection   */
        if ( aes.arch != 0 )                    /* for a modern AES, fill */
                                                /* in the AESINFO string. */
          fs_sset(tree, AESINFO, aes.info, &text, &txtlen);

        /* Set build line in ADDINFO                                      */
        bar = &build[0];
        LSTCPY(ADDR(&G.g_2text[0]), LLGET(LLGET(OB_SPEC(DEBUILD))));
        merge_str(&G.g_1text[0], &G.g_2text[0], &bar);
        LSTCPY(LLGET(LLGET(OB_SPEC(DEBUILD))), ADDR(&G.g_1text[0]));


	shel_get(ADDR(&gl_afile[0]), 1);
	docopyrt = (gl_afile[0] != '#');

	if (docopyrt)
	{
	  tree = G.a_trees[ADDINFO];		/* copyright notice	*/

          status((BYTE FAR *)ini_str(ICNLLINE));

          fsave = LWGET(OB_FLAGS(COPYTEXT));
          LWSET(OB_FLAGS(COPYTEXT), HIDETREE);  /* hide detailed copyrt */
          plong = OB_HEIGHT(ROOT);		/* just upper part	*/
          hsave = LWGET(plong);
          LWSET(plong, (25 * gl_hchar)/2);
          show_hide(FMD_START, tree);

        }

        /*** 20000102 - Holding LeftShift during start will reset all   */
        /* DESKTOP.INF settings.  -- BALJ                               */

        graf_mkstate(&foo, &foo, &foo, &keys);

        if (keys & K_LSHIFT)
          app_reset( TRUE );
        /***/

	rsrc_gaddr(R_STRING, STASTEXT, &ad_ptext);
	rsrc_gaddr(R_STRING, STASICON, &ad_picon);
        rsrc_gaddr(R_STRING, STFITSCR, &ad_pscrn);
        rsrc_gaddr(R_STRING, STFITWIN, &ad_pwin);


						/* These strings are 	*/
						/* used by dr_code.  Can't */
						/* get to resource then	*/
						/* because that would	*/
						/* reenter AES.		*/
	strcpy(ini_str(STAM), &gl_amstr[0]);
	strcpy(ini_str(STPM), &gl_pmstr[0]);
						/* initialize icons 	*/
						/*   and apps from	*/
						/*   shell memory or	*/
						/*   from DESKTOP.INF	*/
						/*   and DESKHI/LO.ICN	*/

	if (!app_start())
	{
	  fun_alert(1, STNOFILE, NULLPTR);
	  pro_exit(G.a_cmd, G.a_tail);
	  return(FALSE);
	}

        if (docopyrt)
          {
            show_hide(FMD_START, tree);         /* Bugfix - under PPD */
                                                /* AES, dialog didn't */
                                                /* draw unless app_start() */
                                                /* is called first. BALJ*/
            app_detect();
          }

#if MULTIAPP
	LSTCPY(G.a_cmd, ADDR("GEMVDI.EXE"));	/* get boot drive */
	shel_find(G.a_cmd);
	gl_bootdr = G.g_cmd[0];
	gl_untop = 0;

	proc_shrink(DESKPID);

	proc_info(DESKPID,&junk1,&junk2,&pr_begdsk,&csize,&pr_topmem,
						&pr_ssize,&pr_itbl);

	pr_begdsk = LOFFSET(pr_begdsk);		/* start of desk	*/
	pr_topdsk = pr_begdsk + csize;		/* addr above desktop	*/
	pr_topmem = LOFFSET(pr_topmem);

	csize = (pr_topmem - pr_begdsk) >> 10;		/* K app space	*/
	merge_str(&memszstr[0], "%L", &csize);		/* to ASCII	*/
	iac_strcop(G.a_trees[ADDINFO], DEMEMSIZ, ADDR(&memszstr[0]));
	
	proc_info(GEMPID,&junk1,&junk2,&pr_beggem,&csize,&templn,
						&pr_ssize,&templn);
	pr_beggem = LOFFSET(pr_beggem);
	pr_begacc = pr_beggem + csize;			/* start of acc's */
	iac_init();
#endif

						/* initialize windows	*/
        status((BYTE FAR *)ini_str(INITLINE));

	win_start();
						/* initialize folders,	*/
						/*   paths, and drives	*/
	fpd_start();

						/* show menu		*/
	desk_verify(0, FALSE);			/* should this be here	*/
        wind_update(BEG_UPDATE);                

        menu_bar(G.a_trees[ADMENU], TRUE);
	wind_update(END_UPDATE);

        on_newgem = 0;
        if ( !aes.arch )                        /* Non-FreeGEM?  No     */
          men_list(G.a_trees[ADMENU], oldcol, FALSE);   /* SETTINGS.APP */
        else
          on_newgem = -1;

#if SINGLAPP
        menu_ienable(G.a_trees[ADMENU], IACCITEM, FALSE); /* Disable accs */
        tree = G.a_trees[ADINSAPP];
        LWSET(OB_FLAGS(APMEMSZ), LWGET(OB_FLAGS(APMEMSZ)) | HIDETREE);
        tree = G.a_trees[ADDINFO];
        LWSET(OB_FLAGS(DEMEMSIZ), LWGET(OB_FLAGS(DEMEMSIZ)) | HIDETREE);
        LWSET(OB_FLAGS(DEMEMSTR), LWGET(OB_FLAGS(DEMEMSIZ)) | HIDETREE);
#endif

                                                /* establish menu items */
						/*   that need to be	*/
						/*   checked, check 'em	*/
	G.g_iview = V_ICON;
	menu_text(G.a_trees[ADMENU], ICONITEM, ad_ptext);
	G.g_csortitem = NAMEITEM;
	menu_icheck(G.a_trees[ADMENU], G.g_csortitem, TRUE);

        G.g_fittowin = 1;             /* BALJ 19990716        */
        menu_text(G.a_trees[ADMENU], ATSWITEM, ad_pwin);

						/* set up initial prefs	*/
	G.g_ccopypref = TRUE;
	G.g_ctimeform = TRUE;
	G.g_cdateform = TRUE;
	G.g_cdclkpref = 3;

        change_bars();

                                                /* initialize desktop	*/
						/*   and its objects	*/
	gl_defdrv = app_blddesk();

						/* fix up subwindows */
						/* changed 5/30/99 -ken */
	for(ii = 0; ii < NUM_WNODES; ii++){
		pws = &G.g_cnxsave.win_save[ii];
		rc_copy(&gl_savewin[ii], &pws->x_save);
		/*if (pws->pth_save[0])
			do_xyfix(&pws->x_save, &pws->y_save);*/
		} /*for*/

        send_upd();

        status((BYTE FAR *)ini_str(DONELINE));  /* Init complete        */
        show_hide(FMD_FINISH, tree);

        LWSET(OB_FLAGS(COPYTEXT), fsave);     /* reveal real copyright */
        LWSET(OB_FLAGS(SPLASH), HIDETREE);    /* hide splash copy/info */
        LWSET(plong, hsave);                  /* ABOUT height restored */
        
                                                /* set up current parms */
        desk_verify(0, FALSE);
                                                /* establish desktop's  */
                                                /*   state from info    */
                                                /*   found in app_start,*/
                                                /*   open windows       */
        wind_update(BEG_UPDATE);
        men_update(G.a_trees[ADMENU]);
        cnx_get();
        wind_update(END_UPDATE);

        men_update(G.a_trees[ADMENU]);

        /* BALJ - 19990715 - cosmetic changes                           */
        /*   Authors dialog has new 3D DRI icon - if old AES, hide it   */
        /*   otherwise hide the blue one used by default.               */

        tree = G.a_trees[AUTHOR];
        if ( !aes.arch)
        {
          /* Old AES */
          LWSET(OB_FLAGS(THREED1), HIDETREE);
          LWSET(OB_FLAGS(THREED2), HIDETREE);
        }
        else
        {
          /* New AES */
          LWSET(OB_FLAGS(FLAT), HIDETREE);
        }


                                                /* get ready for main   */
						/*   loop		*/
	flags = MU_BUTTON | MU_MESAG | MU_KEYBD;
	done = FALSE;
	ig_close = FALSE;
						/* turn mouse on	*/

	desk_wait(FALSE);
						/* loop handling user	*/
						/*   input until done	*/

	while( !done )
	{
						/* block for input	*/
          ev_which = evnt_multi(flags, 0x102, 0x03, 0x00, 
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				G.a_rmsg, 0, 0, 
				&mx, &my, &button, &kstate, &kret, &bret);
						/* grab the screen	*/
	  wind_update(BEG_UPDATE);
						/* handle keybd message */
	  if (ev_which & MU_KEYBD)
	    done = hndl_kbd(kret);

						/* handle button down	*/
	  if (ev_which & MU_BUTTON)
	    done = hndl_button(bret, mx, my, button, kstate);

						/* handle system message*/
	  while (ev_which & MU_MESAG)
	  {
	    done = hndl_msg();
						/* use quick-out to clean */
						/* out all messages	  */
	    if (done)
	      break;
	    ev_which = evnt_multi(MU_MESAG | MU_TIMER, 0x02, 0x01, 0x01, 
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				G.a_rmsg, 0, 0, 
				&mx, &my, &button, &kstate, &kret, &bret);
	  }

						/* free the screen	*/
	  wind_update(END_UPDATE);
	}
						/* save state in memory	*/
						/*   for when we come	*/
						/*   back to the desktop*/
	cnx_put();
	app_save(FALSE);
        if ( G.g_saveonexit )                   /* save to disk?        */
          app_save(TRUE);                       /* BALJ - SOE           */

						/* turn off the menu bar*/
	menu_bar(0x0L, FALSE);
						/* close gsx virtual ws	*/
	gsx_vclose();
						/* exit the gem AES	*/
	appl_exit();
	return(TRUE);
} /* main */

