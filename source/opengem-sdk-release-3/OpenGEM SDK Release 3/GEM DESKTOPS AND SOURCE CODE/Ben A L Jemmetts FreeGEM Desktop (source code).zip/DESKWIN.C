/*      DESKWIN.C    06/11/84 - 04/01/8                 Lee Lorenzen*/
/*					4/7/86			MDF */
/*	for 3.0				11/4/87 - 11/19/87	mdf */
/*	do_movsiz       		5/30/99			BALJ*/
/*	window attribute defs  		5/30/99			KWM */
/*	win_sinfo (infoline)		5/30/99			KWM */
/*	do_xyfix() for move window	5/30/99	 		KWM */
/*	fixed window topping problem	7/01/99	  WF_TATTRB	KWM */
/*      Fit to screen/window            19990716               BALJ */
/*      Window shrink on close          19990905               BALJ */
/*      fixed window open/close probs   20000422               BALJ */

/*
*       Copyright 1999, Caldera Thin Clients, Inc.
*       This software is licenced under the GNU Public License.
*       Please see LICENSE.TXT for further information.
*
*                  Historical Copyright
*      -------------------------------------------------------------
*      GEM Desktop                                       Version 3.0
*      Serial No.  XXXX-0000-654321              All Rights Reserved
*      Copyright (C) 1987                      Digital Research Inc.
*      -------------------------------------------------------------
*/

#include <portab.h>
#include <machine.h>
#include <obdefs.h>
#include <deskapp.h>
#include <deskfpd.h>
#include <deskwin.h>
#include <dos.h>
#include <infodef.h>
#include <desktop.h>
#include <gembind.h>
#include <deskbind.h>
#define abs(x) ( (x) < 0 ? -(x) : (x) )

/* -------------------------------------------------------------------------*/
/* Window Attributes                        added 5/23/99 -ken              */

#define NAME        0x0001
#define CLOSER      0x0002
#define FULLER      0x0004
#define MOVER       0x0008
#define INFO        0x0010
#define SIZER       0x0020
#define UPARROW     0x0040
#define DNARROW     0x0080
#define VSLIDE      0x0100
#define LFARROW     0x0200
#define RTARROW     0x0400
#define HSLIDE	    0x0800
#define HOTCLOSE    0x1000
#define HOTCLOSEBOX 0x1000 			/* for compatibility */

#define WN_PART1        NAME|CLOSER|FULLER|MOVER|INFO|SIZER
#define WN_PART2        UPARROW|DNARROW|VSLIDE|LFARROW|RTARROW|HSLIDE
#define WN_PART3	HOTCLOSE|HOTCLOSEBOX
#define WKIND		WN_PART1|WN_PART2|WN_PART3

/*-------------------------------------------------------------------*/

#define LEN_FNODE 47
#define MIN_HINT 2
#define SPACE 0x20

					/* infoline	6/1/99 -ken     */
EXTERN VOID    my_itoa();		/* 		in deskinf.c	*/
EXTERN VOID    merge_str();		/* 		in opimize.c	*/

						/* in SIMPOSIF.A86     */
EXTERN LONG    drawaddr;
                                                /* in DESKAPP.C         */
EXTERN ANODE   *app_afind();
                                                /* in DESKOBJ.C         */
EXTERN WORD    obj_init();
EXTERN WORD    obj_walloc();
EXTERN WORD    obj_wfree();
EXTERN WORD    obj_ialloc();
                                                /* in DESKFPD.C         */
EXTERN FNODE   *pn_sort();
EXTERN WORD    wind_create();
EXTERN WORD    wind_set();
EXTERN WORD    wind_delete();
EXTERN WORD    objc_order();
EXTERN WORD    min();
EXTERN WORD    movs();
EXTERN WORD    mul_div();
EXTERN WORD    wind_get();
EXTERN WORD    max();
EXTERN WORD    rc_copy();
EXTERN WORD    rc_intersect();
EXTERN WORD    rc_equal();
EXTERN WORD    gsx_sclip();
EXTERN WORD    bb_screen();
						/* in DESKSUPP.C */
EXTERN VOID    do_align();			/* added 7/01/99 -ken */
EXTERN VOID    do_xyfix();                      /* added 6/25/99 -ken */
EXTERN WORD    do_wredraw();
EXTERN WORD    fun_msg();

EXTERN WORD    wind_close();

EXTERN BYTE    *ini_str();

EXTERN WORD    gl_wchar;
EXTERN WORD    gl_hchar;
EXTERN WORD    gl_height;
EXTERN GRECT   gl_rfull;
/* BugFix  */
EXTERN ICONBLK gl_icons[];
EXTERN WORD    gl_whsiztop;
/* */

EXTERN VOID     graf_shrinkbox();
EXTERN VOID	desk_verify();
EXTERN GLOBES	G;

EXTERN BYTE     clrs_wind;

        VOID
win_view(vtype, isort)
        WORD           vtype;
        WORD           isort;
{
        G.g_iview = vtype;
        G.g_isort = isort;

        switch(vtype)
        {
          case V_TEXT:
                G.g_iwext = LEN_FNODE * gl_wchar;
                G.g_ihext = gl_hchar;
                G.g_iwint = (2 * gl_wchar) - 1;
                G.g_ihint = 2;
                G.g_num = G.g_nmtext;
                G.g_pxy = &G.g_xytext[0];
                break;
          case V_ICON:
                G.g_iwext = G.g_wicon;
                G.g_ihext = G.g_hicon;
                G.g_iwint = (gl_height <= 300) ? 0 : 8;
                G.g_ihint = MIN_HINT;
                G.g_num = G.g_nmicon;
                G.g_pxy = &G.g_xyicon[0];
                break;
        }
        G.g_iwspc = G.g_iwext + G.g_iwint;
        G.g_ihspc = G.g_ihext + G.g_ihint;
        G.g_incol = (G.g_wfull - gl_wchar) / G.g_iwspc;
}

/*
*      Start up by initializing global variables
*/
        VOID
win_start()
{
        WNODE          *pw;
        WORD           i;

        obj_init();
        win_view(V_ICON, S_NAME);

        for(i=0; i<NUM_WNODES; i++)
        {
          pw = &G.g_wlist[i];
          pw->w_id = 0;
        }
        G.g_wcnt = 0x0;
}

/*
*      Free a window node.
*/
        VOID
win_free(thewin)
        WNODE          *thewin;
{
        WORD            x,y,w,h;        /* BALJ 19990905 */
        GRECT          *pt;
        WORD            i;

        /* BALJ 19990718 - changed so it now works.     */
        
        if (thewin->w_id != -1)
        {
                                        /* BALJ 19990905 */
          wind_get(thewin->w_id, WF_CXYWH, &x, &y, &w, &h);
          graf_shrinkbox(2*gl_wchar, 0, 4*gl_wchar, gl_hchar, x, y, w, h);
                                        /* Ends 19990905 */
          wind_close(thewin->w_id);     /* This line... */
          wind_delete(thewin->w_id);
          G.g_wcnt--;
          objc_order(G.a_screen, thewin->w_root, 1);
          obj_wfree( thewin->w_root, 0, 0, 0, 0 );
          thewin->w_id = -1; /* 20000422 */

          for (i=0; i < NUM_WNODES; i++);
          {
            pt = (GRECT *) &G.g_cnxsave.win_save[i].x_save;
            pt->g_x = pt->g_y = pt->g_w = pt->g_h = 0;
          }

          if (G.g_wcnt)
            /* Find first open window - BALJ, 20000422       */
            for (G.g_cwin=0; G.g_wlist[G.g_cwin].w_id <= 0; G.g_cwin++);
          else G.g_cwin = 0;

          cnx_put();
        }
}

/*
*      Allocate a window for use as a folder window
*/
        WNODE
*win_alloc()
{
        WNODE          *pw;
        WORD           wob, wnum;
        GRECT          *pt;

        if (G.g_wcnt == NUM_WNODES)
          return((WNODE *) NULL);

        /* Find first free window - BALJ, 20000422       */
        for (wnum=0; G.g_wlist[wnum].w_id > 0; wnum++);

        pt = (GRECT *) &G.g_cnxsave.win_save[wnum].x_save;

        if (pt->g_x == 0)
        {
          pt->g_x = G.g_xfull + (2 * gl_wchar * (wnum + 1) );
          pt->g_y = G.g_yfull + (2 * gl_hchar * (wnum + 1) );
          pt->g_w = G.g_wfull / 2;
          pt->g_h = G.g_hfull / 2;
        }

        wob = obj_walloc(pt->g_x, pt->g_y, pt->g_w, pt->g_h);
        if (wob)
        {
          pw = &G.g_wlist[wnum];
          pw->w_flags = 0x0;
          pw->w_root = wob;
          pw->w_cvcol = 0x0;
          pw->w_cvrow = 0x0;
          pw->w_obid = 0;
          pw->w_pncol = (pt->g_w  - gl_wchar) / G.g_iwspc;
          pw->w_pnrow = (pt->g_h - gl_hchar) / G.g_ihspc;
          pw->w_vncol = 0x0;
          pw->w_vnrow = 0x0;
/* BugFix      */
			       /* 0x1000 = hot closer button  */
				/* original gem/3 default type 0x11c7 */

	pw->w_id = wind_create(WKIND, G.g_xfull, G.g_yfull,
				      G.g_wfull, G.g_hfull);

/*
 NAME | CLOSER | FULLER | MOVER | INFO | SIZER | UPARROW | DNARROW
 VSLIDE | LFARROW | RTARROW | HSLIDE | HOTCLOSEBOX or HOTCLOSE
 */

/*                            change WA_SUBWIN to WA_KEEPWIN 7/1/99 -ken */

	if (pw->w_id != -1){
		wind_set(pw->w_id, WF_TATTRB, WA_KEEPWIN, 0, 0, 0, 0);
                G.g_wcnt++;
		return(pw);
		}
        else {
                pt->g_x = pt->g_y = pt->g_w = pt->g_h = 0;
		win_free(pw);
		}
         }
          return((WNODE *) NULL);
}

/*
*      Find the WNODE that has this id.
*/
        WNODE
*win_find(wh)
        WORD           wh;
{
        WORD           ii;

        for(ii = 0; ii < NUM_WNODES; ii++)
        {
          if ( G.g_wlist[ii].w_id == wh )
            return(&G.g_wlist[ii]);
        }
        return(0);
}

/*
*      Bring a window node to the top of the window list.
*/
        VOID
win_top(thewin)
        WNODE          *thewin;
{
        objc_order(G.a_screen, thewin->w_root, NIL);
}

/*
*      Find out if the window node on top has size, if it does then it
*      is the currently active window.  If not, then no window is on
*      top and return 0.
*/

/*
        WNODE
*win_ontop()
{
        WORD           wob;

        wob = G.g_screen[ROOT].ob_tail;
        if (G.g_screen[wob].ob_width && G.g_screen[wob].ob_height)
          return(&G.g_wlist[wob-2]);
        else
          return(0);
}
*/

/*
*      Find the window node that is the ith from the bottom.  Where
*      0 is the bottom (desktop surface) and 1-4 are windows.
*/
        WORD
win_cnt(level)
        WORD           level;
{
        WORD           wob;
                                                /* skip over desktop   */
                                                /*   surface and count */
                                                /*   windows           */
        wob = G.g_screen[ROOT].ob_head;
        while(level--)
          wob = G.g_screen[wob].ob_next;
        return(wob-2);
}

/*
*      Find the window node that is the ith from the bottom.  Where
*      0 is the bottom (desktop surface) and 1-4 are windows.
*/
        WNODE
*win_ith(level)
        WORD           level;
{
        return(&G.g_wlist[win_cnt(level)]);
}

/*
*      Calculate a bunch of parameters related to how many file objects
*      will fit in a full-screen window.
*/
        VOID
win_ocalc(pwin, wfit, hfit, ppstart)
        WNODE          *pwin;
        WORD           wfit, hfit;
        FNODE          **ppstart;
{
        FNODE          *pf;
        WORD           start, cnt, w_space;
        WORD            w_incol;
        WORD            xc, yc, wc, hc;
                                                /* zero out obid ptrs  */
                                                /*   in flist and count        */
                                                /*   up # of files in  */
                                                /*   virtual file space        */
        cnt = 0;
        for( pf=pwin->w_path->p_flist; pf; pf=pf->f_next)
        {
          pf->f_obid = NIL;
          cnt++;
        }

        /* BALJ - wrapping support - 19990716.                          */
        /* Routine changed to allow switch between Window and Screen    */
        /* icon arrangements.  G.g_incol references changed to w_incol. */
        /* Next statement calculates appropriate w_incol.               */

        if ( G.g_fittowin == 0 )
          w_incol = G.g_incol;
        else
        {
          wind_get(pwin->w_id, WF_CXYWH, &xc, &yc, &wc, &hc);
          w_incol = (wc - gl_wchar) / G.g_iwspc;
        }

                                                /* set windows virtual */
                                                /*   number of rows and        */
                                                /*   columns           */
        pwin->w_vncol = (cnt < w_incol) ? cnt : w_incol;
        pwin->w_vnrow = cnt / w_incol;
        if (cnt % w_incol)
          pwin->w_vnrow += 1;
        if (!pwin->w_vnrow)
          pwin->w_vnrow++;
        if (!pwin->w_vncol)
          pwin->w_vncol++;
                                                /* backup cvrow & cvcol        */
                                                /*   to account for    */
                                                /*   more space in wind.*/
        if (!wfit)
          wfit++;
        w_space = pwin->w_pncol = min(wfit, pwin->w_vncol);
        while( (pwin->w_vncol - pwin->w_cvcol) < w_space )
          pwin->w_cvcol--;
        if (!hfit)
          hfit++;
        w_space = pwin->w_pnrow = min(hfit, pwin->w_vnrow);
        while( (pwin->w_vnrow - pwin->w_cvrow) < w_space )
          pwin->w_cvrow--;
                                                /* based on windows    */
                                                /*   current virtual   */
                                                /*   upper left row &  */
                                                /*   column calculate  */
                                                /*   the start and stop        */
                                                /*   files             */
        start = (pwin->w_cvrow * w_incol) + pwin->w_cvcol;
        pf = pwin->w_path->p_flist;
        while ( (start--) && pf)
          pf = pf->f_next;
        *ppstart = pf;
}

/*
*      Calculate a bunch of parameters dealing with a particular
*      icon.
*/
        VOID
win_icalc(pfnode)
        FNODE          *pfnode;
{
        if (pfnode->f_attr & F_DESKTOP)
          return;

        if (pfnode->f_attr & F_SUBDIR)
          pfnode->f_pa = app_afind(FALSE, AT_ISFOLD, -1,
                                &pfnode->f_name[0], &pfnode->f_isap);
        else
          pfnode->f_pa = app_afind(FALSE, AT_ISFILE, -1,
                                &pfnode->f_name[0], &pfnode->f_isap);
}

/*
*      Build an object tree of the list of files that are currently
*      viewable in a full-screen virtual window.  Next adjust root of
*      tree to take into account the current view of the full-screen
*      through a window on the physical display.
*/
        VOID
win_bldview(pwin, x, y, w, h)
        WNODE          *pwin;
        WORD           x, y, w, h;
{
        FNODE          *pstart;
        WORD           obid, skipcnt;
        WORD           r_cnt, c_cnt;
        WORD           o_wfit, o_hfit;         /* object grid          */
        WORD           i_index, i;
        WORD           xoff, yoff, wh, sl_size, sl_value;
                                                /* free all this windows*/
                                                /*   kids and set size */
        obj_wfree(pwin->w_root, x, y, w, h);

        G.g_screen[pwin->w_root].ob_spec &= 0xffffff00L;
        G.g_screen[pwin->w_root].ob_spec |= clrs_wind;


                                                /* make pstart point at        */
                                                /*   1st file in current*/
                                                /*   view              */
        win_ocalc(pwin, w/G.g_iwspc, h/G.g_ihspc, &pstart);
        o_wfit = min(pwin->w_pncol + 1, pwin->w_vncol - pwin->w_cvcol);
        o_hfit = min(pwin->w_pnrow + 1, pwin->w_vnrow - pwin->w_cvrow);
        r_cnt = c_cnt = 0;
        while ( (c_cnt < o_wfit) &&
                (r_cnt < o_hfit) &&
                (pstart) )
        {
                                                /* calc offset         */
          yoff = r_cnt * G.g_ihspc;
          xoff = c_cnt * G.g_iwspc;
                                                /* allocate object     */
          obid = obj_ialloc(pwin->w_root, xoff + G.g_iwint, yoff + G.g_ihint,
                                 G.g_iwext, G.g_ihext);

          if (!obid)
          {
            /* error case, no more obs */
          }
                                                /* remember it         */
          pstart->f_obid = obid;
                                                /* build object                */
/*          G.g_screen[obid].ob_state = WHITEBAK | DRAW3D; */

          G.g_screen[obid].ob_flags = 0x0;
          switch(G.g_iview)
          {
            case V_TEXT:
                G.g_screen[obid].ob_type = G_USERDEF;
                G.g_screen[obid].ob_spec = ADDR( &G.g_udefs[obid] );
                G.g_udefs[obid].ub_code = drawaddr;
                G.g_udefs[obid].ub_parm = ADDR( &pstart->f_junk );
                win_icalc(pstart);
                break;
            case V_ICON:
                G.g_screen[obid].ob_type = G_ICON;
                win_icalc(pstart);
                i_index = (pstart->f_isap) ? pstart->f_pa->a_aicon :
                                             pstart->f_pa->a_dicon;
                G.g_index[obid] = i_index;
                G.g_screen[obid].ob_spec = ADDR( &gl_icons[obid] );
                movs(sizeof(ICONBLK), &G.g_iblist[i_index], &gl_icons[obid]);
                gl_icons[obid].ib_ptext = ADDR(&pstart->f_name[0]);

                gl_icons[obid].ib_char = clrs_find(pstart, gl_icons[obid].ib_char);

                gl_icons[obid].ib_char |= (0x00ff & pstart->f_pa->a_letter);

                break;
          }
          pstart = pstart->f_next;
          c_cnt++;
          if ( c_cnt == o_wfit )
          {
                                                /* next row so skip    */
                                                /*   next file in virt */
                                                /*   grid              */
            r_cnt++;
            c_cnt = 0;
            skipcnt = pwin->w_vncol - o_wfit;
            while( (skipcnt--) &&
                   (pstart) )
              pstart = pstart->f_next;
          }
        }
                                                /* set slider size &   */
                                                /*   position          */
        wh = pwin->w_id;

		/* this routine calculates window slider positions */
/* BugFix */
	sl_size = mul_div(pwin->w_pncol, 1000, pwin->w_vncol);
        wind_set(wh, WF_HSLSIZ, sl_size, 0, 0, 0);
/*	wind_get(wh, WF_HSLSIZ, &sl_size, &i, &i, &i);*/
	if ( pwin->w_vncol > pwin->w_pncol )
		sl_value = mul_div(pwin->w_cvcol, 1000,
			pwin->w_vncol - pwin->w_pncol);
	else
		sl_value = 0;
	wind_set(wh, WF_HSLIDE, sl_value, 0, 0, 0);
/* */
	sl_size = mul_div(pwin->w_pnrow, 1000, pwin->w_vnrow);
        wind_set(wh, WF_VSLSIZ, sl_size, 0, 0, 0);
/*	wind_get(wh, WF_VSLSIZ, &sl_size, &i, &i, &i); */ /* WHY??? */
	if ( pwin->w_vnrow > pwin->w_pnrow )
		sl_value = mul_div(pwin->w_cvrow, 1000,
				pwin->w_vnrow - pwin->w_pnrow);
        else
		sl_value = 0;
	wind_set(wh, WF_VSLIDE, sl_value, 0, 0, 0);

}

/*
*      Routine to blt the contents of a window based on a new
*      current row or column
*/

win_blt(pw, newcv)
        WNODE          *pw;
        WORD           newcv;
{
        WORD           delcv, pn;
        WORD           sx, sy, dx, dy, wblt, hblt, revblt, tmp;
        GRECT          c, t;

	newcv = max(0, newcv);

        newcv = min(pw->w_vnrow - pw->w_pnrow, newcv);
        pn = pw->w_pnrow;
        delcv = newcv - pw->w_cvrow;
        pw->w_cvrow += delcv;
        if (!delcv)
          return(FALSE);
        wind_get(pw->w_id, WF_WXYWH, &c.g_x, &c.g_y, &c.g_w, &c.g_h);
        win_bldview(pw, c.g_x, c.g_y, c.g_w, c.g_h);
                                                /* see if any part is  */
                                                /*   off the screen    */
/*	rc_copy(&c, &t);
        rc_intersect(&gl_rfull, &t);
        if ( rc_equal(&c, &t) )
        {
*/
						/* blt as much as we can*/
                                                /*   adjust clip & draw        */
                                                /*   the rest          */
/*	  if ( (revblt = (delcv < 0)) != 0 )
            delcv = -delcv;
          if (pn > delcv)
          {
*/
						/* see how much there is*/
                                                /* pretend blt up      */
/*
	    sx = dx = 0;
            sy = delcv * G.g_ihspc;
            dy = 0;
            wblt = c.g_w;
            hblt = c.g_h - sy;
            if (revblt)
            {
              tmp = sx;
              sx = dx;
              dx = tmp;
              tmp = sy;
              sy = dy;
              dy = tmp;
            }
            gsx_sclip(&c);
            bb_screen(S_ONLY, sx+c.g_x, sy+c.g_y, dx+c.g_x, dy+c.g_y,
                        wblt, hblt);
            if (!revblt)
              c.g_y += hblt;
            c.g_h -= hblt;
          }
        }
*/
	do_wredraw(pw->w_id, c.g_x, c.g_y, c.g_w, c.g_h);
}

win_hblt(pw, newcv)			/* temp horizblt 5/30/99 -ken  */
        WNODE          *pw;
        WORD           newcv;
{
        WORD           delcv, pn;
        WORD           sx, sy, dx, dy, wblt, hblt, revblt, tmp;
        GRECT          c, t;

	newcv = max(0, newcv);

	newcv = min(pw->w_vncol - pw->w_pncol, newcv);
	pn = pw->w_pncol;
	delcv = newcv - pw->w_cvcol;
	pw->w_cvcol += delcv;
        if (!delcv)
          return(FALSE);
        wind_get(pw->w_id, WF_WXYWH, &c.g_x, &c.g_y, &c.g_w, &c.g_h);
        win_bldview(pw, c.g_x, c.g_y, c.g_w, c.g_h);

						/* see if any part is  */
                                                /*   off the screen    */
/*	rc_copy(&c, &t);
        rc_intersect(&gl_rfull, &t);

	if ( rc_equal(&c, &t) ) {
	  if ( (revblt = (delcv < 0)) != 0 )  delcv = -delcv;
	  if (pn > delcv) {
		    sx = dx = 0;
		    sy = delcv * G.g_ihspc;
		    dy = 0;
		    wblt = c.g_w;
		    hblt = c.g_h - sy;

	    if (revblt) {
		      tmp = sx;
		      sx = dx;
		      dx = tmp;
		      tmp = sy;
		      sy = dy;
		      dy = tmp;
		    }

	    gsx_sclip(&c);
            bb_screen(S_ONLY, sx+c.g_x, sy+c.g_y, dx+c.g_x, dy+c.g_y,
                        wblt, hblt);
            if (!revblt)
	      c.g_y += hblt;
	    c.g_h -= hblt;
	  }
	}
*/

	do_wredraw(pw->w_id, c.g_x, c.g_y, c.g_w, c.g_h);
}

/*
*      Routine to change the current virtual row or column being viewed
*      in the upper left corner based on a new slide amount.
*/
        VOID
win_slide(wh, sl_value)
        WORD           wh;
        WORD           sl_value;
{
        WNODE          *pw;
        WORD           newcv;
        WORD           vn, pn, i, sls, sl_size;

        pw = win_find(wh);

        vn = pw->w_vnrow;
        pn = pw->w_pnrow;
        sls = WF_VSLSIZ;
        wind_get(wh, sls, &sl_size, &i, &i, &i);
        newcv = mul_div(sl_value, vn - pn, 1000);
	win_blt(pw, newcv);

}

        VOID
win_hslide(wh, sl_value)			/* temp 5/30/99 -ken */
        WORD           wh;
        WORD           sl_value;
{
        WNODE          *pw;
        WORD           newcv;
        WORD           vn, pn, i, sls, sl_size;

        pw = win_find(wh);

	vn = pw->w_vncol;
	pn = pw->w_pncol;
	sls = WF_HSLSIZ;
        wind_get(wh, sls, &sl_size, &i, &i, &i);
        newcv = mul_div(sl_value, vn - pn, 1000);
	win_hblt(pw, newcv);

}

/*
*      Routine to change the current virtual row or column being viewed
*      in the upper left corner based on a new slide amount.
*/
        VOID
win_arrow(wh, arrow_type)
        WORD           wh;
        WORD           arrow_type;
{
        WNODE          *pw;
        WORD           newcv;

	pw = win_find(wh);
        switch(arrow_type)
        {
          case WA_UPPAGE:
                newcv = pw->w_cvrow - pw->w_pnrow;
                break;
          case WA_DNPAGE:
                newcv = pw->w_cvrow + pw->w_pnrow;
                break;
          case WA_UPLINE:
                newcv = pw->w_cvrow - 1;
                break;
          case WA_DNLINE:
                newcv = pw->w_cvrow + 1;
                break;

	  case WA_LFPAGE:
		newcv = pw->w_cvcol - pw->w_pncol;
                break;
	  case WA_RTPAGE:
		newcv = pw->w_cvcol + pw->w_pncol;
                break;
	  case WA_LFLINE:
		newcv = pw->w_cvcol - 1;
                break;
	  case WA_RTLINE:
		newcv = pw->w_cvcol + 1;
                break;

	}

	if(arrow_type<4)
		win_blt(pw, newcv);
	else
		win_hblt(pw, newcv);

}

/*
*      Routine to sort all existing windows again
*/
        VOID
win_srtall()
{
        WORD           ii;
        WORD           sortsave;


        for(ii=0; ii<NUM_WNODES; ii++)
        {
          if ( G.g_wlist[ii].w_id != 0 )
          {
            sortsave = G.g_isort;
            G.g_wlist[ii].w_cvrow = 0;             /* reset slider         */
            if (G.g_wlist[ii].w_path->p_spec[0] == '@')    /* disk icon    */
              G.g_isort = S_DISK;            /* sort by drive letter */
            G.g_wlist[ii].w_path->p_flist = pn_sort(-1,
                                        G.g_wlist[ii].w_path->p_flist);
            G.g_isort = sortsave;
          }
        }
} /* win_srtall */

/*
*      Routine to build all existing windows again.
*/
        VOID
win_bdall()
{
        WORD           ii;
        WORD           wh, xc, yc, wc, hc;

        for (ii = 0; ii < NUM_WNODES; ii++)
        {
          wh = G.g_wlist[ii].w_id;
          if ( wh != 0 )
          {
            wind_get(wh, WF_WXYWH, &xc, &yc, &wc, &hc);
	    win_bldview(&G.g_wlist[ii], xc, yc, wc, hc);
          }
        }
}

/*
*      Routine to draw all existing windows.
*/
        VOID
win_shwall()
{
        WORD           ii;
        WORD           xc, yc, wc, hc;

        WORD           justtop, wh;

        justtop = FALSE;
        for(ii = 0; ii < NUM_WNODES; ii++)
        {
          if (( wh = G.g_wlist[ii].w_id ) != 0)  /* yes, assignment!     */
          {

        /* BALJ 19990716 - Now windows can be moved, only drawing the fulled */
        /*                 one seems a bit dumb, so this part commented out. */

        /*  if (gl_whsiztop != NIL)          /! if some wh is fulled !/
            {
              if (gl_whsiztop == wh)         /!  and its this one    !/
                justtop = TRUE;              /!  just to this wh     !/
              else                           /!  else test next wh   !/
                continue;
            }                                            END 19990716 */
            wind_get(wh, WF_WXYWH, &xc, &yc, &wc, &hc);
            fun_msg(WM_TOPPED, wh, xc, yc, wc, hc);
            fun_msg(WM_REDRAW, wh, xc, yc, wc, hc);
            if (justtop)
              return; 
          } /* if */
        } /* for */
} /* win_shwall */

/*
*      Return the next icon that was selected after the current icon.
*/
        WORD
win_isel(olist, root, curr)
        OBJECT         olist[];
        WORD           root;
        WORD           curr;
{
        if (!curr)
          curr = olist[root].ob_head;
        else
          curr = olist[curr].ob_next;

        while(curr > root)
        {
          if ( olist[curr].ob_state & SELECTED )
            return(curr);
          curr = olist[curr].ob_next;
        }
        return(0);
}

/*
*      Return pointer to this icons name.  It will always be an icon that
*      is on the desktop.
*/
        BYTE
*win_iname(curr)
        WORD           curr;
{
        ICONBLK                *pib;
        BYTE           *ptext;

        pib = (ICONBLK *) LPOINTER(G.g_screen[curr].ob_spec);
        ptext = (BYTE *) LPOINTER(pib->ib_ptext);
        return( ptext );
}

/*
*      Set the name line of a particular window
*/
        VOID
win_sname(pw)
        WNODE          *pw;
{
	BYTE	       ascii[16], buffer[256];
        BYTE           *psrc;
        BYTE           *pdst;

        psrc = &pw->w_path->p_spec[0];
        pdst = &pw->w_name[0];
        if (*psrc != '@') {
	  while ( (*psrc) && (*psrc != '*') )
		*pdst++ = *psrc++;
		}
        else
		pdst = strcpy(ini_str(STDSKDRV), pdst);

	*pdst = NULL;
}

/************************************************************************/
/*      Set the infoline of a window		infoline 5/30/99  -ken  */
/*									*/
/*      insert temp window id#                           7/01/99  -ken  */
/*                                                                      */
/*      use free strings from .RSC file                 08/31/99  BALJ  */
/*       - helps with future i18n.                                      */
/*                                                                      */
/************************************************************************/

	VOID
win_sinfo(pw)
        WNODE          *pw;
{
        BYTE           ascii[64], buffer[256];
        BYTE           *psrc;
        BYTE           *pdst;

	WORD		tmp;


		ascii[0] = 0;
		buffer[0] = 0;
		pdst = &pw->w_info[0];

		/*strcat(" ", &buffer);*/
                merge_str(&ascii[0], "%W:", &pw->w_id );
                strcat(ascii, &buffer);

		if( pw->w_path->p_size > 0){
                        merge_str(&ascii[0], ini_str(STINFOS1), &pw->w_path->p_size);
			strcat(ascii, &buffer);
			}

                merge_str(&ascii[0], ini_str(STINFOS2), &pw->w_path->p_count);
                strcat(ascii, &buffer);

		psrc = &buffer[0];
		pdst = strcpy(psrc, pdst);

		*pdst = NULL;

} /* win_sinfo */

        VOID
do_movsiz(pw, x, y, w, h)			/* added    5/30/99  BALJ */
                                                /* 19991223 - now redraws */
        WNODE           *pw;
	WORD		x, y, w, h;
{
	WORD            new_w, min_w;
        WORD            xc, yc, wc, hc;
        /* We need to set a limit on width for text views */

        if (G.g_iview == V_TEXT){
                min_w = ( LEN_FNODE + 5) * gl_wchar;
		new_w = (w <= min_w) ? min_w : w;
		}
        else  new_w = w;

	do_xyfix(&x, &y);
        wind_set(pw->w_id, WF_CXYWH, x, y, new_w, h);

        desk_verify(pw->w_id, TRUE);
        wind_get(pw->w_id, WF_WXYWH, &xc, &yc, &wc, &hc);
        do_wredraw(pw->w_id, xc, yc, wc, hc);

} /* do_movsiz */

