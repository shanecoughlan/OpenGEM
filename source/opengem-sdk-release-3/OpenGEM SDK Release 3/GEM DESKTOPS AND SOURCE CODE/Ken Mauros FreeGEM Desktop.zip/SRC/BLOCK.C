	WORD		junk;		/* trashcan support 11/11/99 -ken */
	ANODE		*pa;
	WNODE		*pw;
	FNODE		*pf;
