README for gconfig 0.1
======================

Known glitches with gconfig -

- It assumes FreeGEM is installed in the \GEMAPPS directory on the drive gconfig.exe is on. I don't know if this is a valid assumption or not.
- I don't know how it will behave if there are comments in the GEMSYS.CFG
  file.  It will almost certainly muck up, due to my not having put the code
to deal with them into the file reader yet.
- The program will not accept any command line switches (even /?) if the GEMSYS.CFG file isn't there.
- It was written in Turbo Pascal 6.  I don't know if it will compile with other version.
- The code is ugly.

This will, in all probability, be released under the GPL when it gets finished.  Until then it's just sort of in limbo.

Disclaimer, no guarantees, etc.  Even though I'll probably feel very guilty if it does anything baad.  I've tested this on my own computer, but it may well barf on yours.  Don't run it on anything critical.
