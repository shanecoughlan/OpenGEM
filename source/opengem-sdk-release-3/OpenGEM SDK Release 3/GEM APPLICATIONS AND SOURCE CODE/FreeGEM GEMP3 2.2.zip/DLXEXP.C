/*******************************************************************************/
/* GEMP3 2.1: An MP3 player for GEM                                            */
/* Copyright (c) Owen Rudge 2000-2001. Uses LibAmp, Allegro and DJGPP          */
/*                                                                             */
/* The code in MP3PLAY.CC is from SETEdit. Window/button code by Heinz Rath    */
/* Please see http://www.owenrudge.co.uk/GEM/ for more information.            */
/*                                                                             */
/* This application is licensed under the terms of the General Public License, */
/* version 2.0 or higher. See the included LICENSE.TXT for details.            */
/*******************************************************************************/

//#define INCLUDE_ALLEGRO_EXPORTS

#include <conio.h>
#include <stdio.h>

#ifdef INCLUDE_ALLEGRO_EXPORTS
   #include <allegro.h>
#endif

#include "djgppgem.h"
#include "djc.h"
#include "dlx.h"

extern GEMP3_SetLabel(int lbl, const char *txt);
extern int get_file(char *fn_out, char *title, char *type);
extern char * ReadLangStr(int id);
extern void GEM_ShowProgressDialog();

BOOLEAN GEMP3_ShowDialog = 0; // FALSE

DLXUSE_BEGIN
   LIBEXPORT_BEGIN
     #include "crtl.exp"

     LIBEXPORT(dj_form_alert)
     LIBEXPORT(GEMP3_SetLabel)
     LIBEXPORT(get_file)
     LIBEXPORT(ReadLangStr)

     LIBEXPORT(GEMP3_ShowDialog)
     LIBEXPORT(GEM_ShowProgressDialog)
   LIBEXPORT_END
DLXUSE_END

void ExportDLXTable()
{
   DLXImport(_LIBEXPORTTABLE);
}