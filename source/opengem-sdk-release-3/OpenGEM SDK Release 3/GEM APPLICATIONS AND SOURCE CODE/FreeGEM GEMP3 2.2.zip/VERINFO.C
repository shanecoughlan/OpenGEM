/*******************************************************************************/
/* GEMP3 2.2: An MP3 player for GEM                                            */
/* Copyright (c) Owen Rudge 2000-2001. Uses LibAmp, Allegro and DJGPP          */
/*                                                                             */
/* The code in MP3PLAY.CC is from SETEdit. Window/button code by Heinz Rath    */
/* Please see http://www.owenrudge.co.uk/GEM/ for more information.            */
/*                                                                             */
/* This application is licensed under the terms of the General Public License, */
/* version 2.0 or higher. See the included LICENSE.TXT for details.            */
/*******************************************************************************/

#include <process.h>
#include <stdio.h>

int main()
{
   spawnl(P_WAIT, "GEMP3.APP", "GEMP3.APP", "/VERINFO", NULL);
   return(0);
}
