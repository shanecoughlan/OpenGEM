/*******************************************************************************/
/* GEMP3 2.1: An MP3 player for GEM                                            */
/* Copyright (c) Owen Rudge 2000-2001. Uses LibAmp, Allegro and DJGPP          */
/*                                                                             */
/* The code in MP3PLAY.CC is from SETEdit. Window/button code by Heinz Rath    */
/* Please see http://www.owenrudge.co.uk/GEM/ for more information.            */
/*                                                                             */
/* This application is licensed under the terms of the General Public License, */
/* version 2.0 or higher. See the included LICENSE.TXT for details.            */
/*******************************************************************************/

/*********************************/
/* Dummy encoder routine         */
/* Copyright (c) Owen Rudge 2001 */
/*********************************/

#include "djgppgem.h"
#include "dlx.h"
#include "lang.h"

void LibMain(int ap_process, hdlx_t id, char* ap_args)
{
   if (ap_process != 0) return;

   dj_form_alert(1, ReadLangStr(LANG_ENCODE_NI));
} DLX_EF;

DLXUSE_BEGIN
  LIBLOADS_BEGIN
  LIBLOADS_END
  LIBEXPORT_BEGIN
  LIBEXPORT_END
DLXUSE_END
