Fonts for Intel GEM
System Fonts

These system fonts are 8x16 fonts for VGA mode, supplied in the PC Screen Format ( PSF1). To use them, you will need to use SYSFONT to install them into your GEM video driver.

In the case of fonts converted from other sources, the characters have been rearranged into the correct positions for GEM, and missing characters synthesized. 